<?php
 include 'session.php';
 if(isset($_SESSION['arr'])){$gg = $_SESSION['arr'];}

?>
<!DOCTYPE html>
<html lang="en">
<link rel="icon" href="images/heading.ico" type="image/x-icon">
<head>

        <title>IL PIACERE</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">

        <!-- Font -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600" rel="stylesheet">
        <link rel="stylesheet" href="fonts/beyond_the_mountains-webfont.css" type="text/css"/>

        <!-- Stylesheets -->
        <link href="plugin-frameworks/bootstrap.min.css" rel="stylesheet">
        <link href="plugin-frameworks/swiper.css" rel="stylesheet">
        <link href="fonts/ionicons.css" rel="stylesheet">
        <link href="common/styles.css" rel="stylesheet">
        <link href="drop.css" rel="stylesheet">
</head>
<body>
<header style= "position: fixed;  top: 0; width: 100%;">

        <div class="container">

                <a class="logo" href="#"><img src="images/logo.png" alt="Logo"></a>
                <div class="right-area">
                                            <h6>

<div class="dropdown">

  <svg  xmlns="http://www.w3.org/2000/svg"  width="50" height="50" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
  <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
  <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"/>
</svg><br>

 <?php 
if(isset($_SESSION['fio'])){echo $_SESSION['fio'];}
?>
  

<div class="dropdown-content">

<?php 

        if(isset($_SESSION['ad_id'])){
          ?>
        <ul style="text-align: center;" >
            <li><a href="logout.php">Выйти</a></li>
        </ul>

             <?php
        }
        ?>
<?php 

      if(isset($_SESSION['adminind'])){
          ?>
        <ul style="text-align: center;" > 
            <li><a href="form-profile.php">Мой профиль</a></li><br>
            <li><a href="logout.php">Выйти</a></li>
        </ul>

             <?php
        } 
        if(isset($_SESSION['adminind'])==false){
       if(isset($_SESSION['ad_id'])==false){
        ?>

  
        <ul style="text-align: center;" >
            <li><a href="login.php">Вход</a></li>
            <li><a href="registration.php">Регистрация</a></li>
        </ul>
        <?php 
      }}
      ?>
      
  
</div>
</div>
                </h6>
                </div><!-- right-area -->


                <a class="menu-nav-icon" data-menu="#main-menu" href="#"><i class="ion-navicon"></i></a>
                <ul class="main-menu font-mountainsre" id="main-menu">
                        <li><a href="index.php">ГЛАВНАЯ</a></li>
                        <li><a href="02_about_us.php">О НАС</a></li>
                        <li><a href="03_menu.php">МЕНЮ</a></li>
                        <li><a href="04_blog.php">НОВОСТИ</a></li>
<?php if(isset($_SESSION['ad_id'])==false) { if(isset($_SESSION['adminind'])) {?><li><a href="05_contact.php">КОНТАКТ</a></li><?php  }}?>
<?php if(isset($_SESSION['adminind'])) {?><li><div class="dropdown"><div class="cart"><a href="Корзина.php" class="plr-20 color-white btn-fill-primary">КОРЗИНА</a></div>
                        <div class="dropdown-content">
                                 <?php if(isset($gg)){if ($gg['1']==0) {?>
          <p>В корзине нет товаров</p><?php
        }
        else{?>
        <p>В корзине <span ><?php echo $gg['1']; ?></span> товаров<br>на сумму <span ><?php echo $gg['0']; ?></span> руб.</p><?php }} 
        else {?>
            <p>В корзине нет товаров</p><?php
        }?>
                        </div> 
                </div>
        </li><?php  }?>
<?php if(isset($_SESSION['ad_id'])) { ?><li><div class="dropdown"><div class="cart"><a href="admin/index.php" class="plr-20 color-white btn-fill-primary">БАЗА ДАННЫХ</a></div></div>
        </li><?php } ?>
                </ul>
                
                <div class="clearfix"></div>

        </div><!-- container -->

</header>
<style>
img { -moz-user-select: none; -webkit-user-select: none; -ms-user-select: none; user-select: none; }
.btn:focus {
outline: none;
box-shadow: none;
}






</style>
