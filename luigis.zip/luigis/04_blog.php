<?php
include 'session.php';?>
<head><title>IL PIACERE:Новости</title></head>
<?php include 'header.php';
?>

<section class="bg-7 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                                <h5><b>ЛУЧШИЙ В ГОРОДЕ</b></h5>
                                <h3 class="mt-30 mb-15">Our News</h3>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>

<?php

include 'loading.php';
if(isset($_POST['submit'])){

$s=$_POST['search'];
$result1 = $db->query("SELECT * FROM posts WHERE `Дата` LIKE '%$s%' OR `Название` LIKE '%$s%' OR `Описание` LIKE '%$s%' ORDER BY id DESC");
?>
<section class="story-area left-text center-sm-text">
        <div class="container">
                <div class="row">
                        <div class="col-md-7 col-lg-8">
<?php 
while ($row = $result1->fetch_assoc())
{
?>
                                <div class="mb-50 mb-sm-30">
                                        <div class="pos-relative mb-30 pt-15">
                                                <div class="font-8 abs-tl p-20 bg-primary color-white">
                                                        <h4><b><?php echo $row['Дата']; ?></b></h4>
                                                        <div class="brdr-style-1"></div>
                                                </div>
                                                <img src="<?php echo $row['Изображение']; ?>" height="400" weight="1000" alt="">
                                        </div>
                                        <h4><a href="#"><b><?php echo $row['Название']; ?></b></a></h4>
                                        <h6 class="mt-10 bg-lite-blue dplay-inl-block">
                                        </h6>
                                        <p class="mt-30"><?php echo $row['Описание']; ?></p>
                                </div><!--mb-30-->
<?php 
}
}

else if(isset($_POST['back'])){ 
  $result1=$db->query("SELECT * FROM posts ORDER BY id DESC");?>

<section class="story-area left-text center-sm-text">
        <div class="container">
                <div class="row">
                        <div class="col-md-7 col-lg-8">

<?php 
while($row=$result1->fetch_assoc()) {?>
<div class="mb-50 mb-sm-30">
                                        <div class="pos-relative mb-30 pt-15">
                                                <div class="font-8 abs-tl p-20 bg-primary color-white">
                                                        <h4><b><?php echo $row['Дата']; ?></b></h4>
                                                        <div class="brdr-style-1"></div>
                                                </div>
                                                <img src="<?php echo $row['Изображение']; ?>" height="400" weight="1000" alt="">
                                        </div>
                                        <h4><a href="#"><b><?php echo $row['Название']; ?></b></a></h4>
                                        <h6 class="mt-10 bg-lite-blue dplay-inl-block">
                                        </h6>
                                        <p class="mt-30"><?php echo $row['Описание']; ?></p>
                                </div><!--mb-30-->
    <?php
  }
}
else{
    $result1 = $db->query("SELECT * FROM posts ORDER BY id DESC");?>

<section class="story-area left-text center-sm-text">
        <div class="container">
                <div class="row">
                        <div class="col-md-7 col-lg-8">

<?php while($row=$result1->fetch_assoc()) {?>
    <div class="mb-50 mb-sm-30">
                                        <div class="pos-relative mb-30 pt-15">
                                                <div class="font-8 abs-tl p-20 bg-primary color-white">
                                                        <h4><b><?php echo $row['Дата']; ?></b></h4>
                                                        <div class="brdr-style-1"></div>
                                                </div>
                                                <img src="<?php echo $row['Изображение']; ?>" height="400" weight="1000" alt="">
                                        </div>
                                        <h4><a href="#"><b><?php echo $row['Название']; ?></b></a></h4>
                                        <h6 class="mt-10 bg-lite-blue dplay-inl-block">
                                        </h6>
                                        <p class="mt-30"><?php echo $row['Описание']; ?></p>
                                </div><!--mb-30-->
<?php
}
}
  ?>
                        </div><!--col-md-8-->

                        <div class="col-md-5 col-lg-4">
                                <div class="mx-w-400x mlr-auto">
                                        <form class="mb-50 mb-sm-30 mt-sm-30 placeholder-1 form-style-1 pos-relative" method="POST" action="04_blog.php">
                                                <input class="pr-50" type="text" placeholder="Поиск"  name="search">
                                                <button class="abs-tbr plr-20" style="left:70%" type="submit" name='submit'><i class="ion-android-search"></i></button>
                                                <button class="abs-tbr plr-20" type="submit" name="back" ><i class="ion-backspace-outline"></i></button>
                                        </form>


                                        <div class="mb-50 mb-sm-30 pos-relative oflow-hidden">
                                                <div class="bg-trinagle-primary"></div>
                                                <img src="images/sidebar-1-400x600.jpg" alt="">
                                                <div class="abs-bl font-18 color-white p-30 z-1">
                                                        <h4 class="lh-1">30%</h4>
                                                        <h4 class="lh-1">off</h4>
                                                        <h6 class="font-5 mt-10">Combo Pack <b>Pizza + Salad</b></h6>
                                                </div>
                                        </div><!--mb-50-->


                                        <div class="mb-50 mb-sm-30">
                                                <h5 class="mb-30 left-text"><b>Последние посты</b></h5>
<?php 
$result2 = $db->query("SELECT * FROM posts ORDER BY id DESC LIMIT 3");
while ($row = $result2->fetch_assoc())
{
?>
                                                <div class="sided-90x mb-30 ">
                                                        <div class="s-left"><img class="br-3" src="<?php echo $row['Изображение']; ?>"height="100" weight="100" alt="Menu Image"></div>
                                                        <div class="s-right left-text">
                                                                <h6 class="font-11 mtb-5"><b><?php echo $row['Название']; ?></b></h6>
                                                                <h6 class="color-primary"><b><?php echo $row['Дата']; ?></b></h6>
                                                        </div><!--s-right-->
                                                </div><!-- sided-90x -->

 <?php } ?>
                                        </div><!--mb-50-->

                                        <div class="mb-30 pos-relative">
                                                <img src="images/sidebar-2-400x600.jpg" alt="">
                                                <div class="font-23  ptb-15 abs-tlr-30 color-white center-text brdr-primary-3">
                                                        <div class="abs-tblr bg-black opacty-6 z--1"></div>
                                                        <h4><b>1 + 1</b></h4>
                                                        <h6 class="font-5 pb-15"><b>Buy one get one</b></h6>
                                                </div>
                                        </div><!--mb-50-->

                                </div><!--mx-w-500x-->
                        </div><!--col-md-4-->
                </div><!-- row -->
        </div><!-- container -->
</section>

<?php
include 'footer.php';
?>
<!-- SCIPTS -->
<script src="plugin-frameworks/jquery-3.2.1.min.js"></script>
<script src="plugin-frameworks/bootstrap.min.js"></script>
<script src="plugin-frameworks/swiper.js"></script>
<script src="common/scripts.js"></script>

</body>
</html>