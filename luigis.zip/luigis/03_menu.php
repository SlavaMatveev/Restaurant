<?php
include 'session.php';
include 'loading.php';
?>


<head><title>IL PIACERE:Меню</title></head>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="images/heading.ico" type="image/x-icon">
<meta charset="UTF-8">
<style>
.button {
  padding: 15px 25px;
  font-size: 24px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #EF0031;
  background-color: white;
  border: 1px solid #EF0031;

}
 .button:hover {background-color: #EF0031;
color: white;
 }

.button:active {
  background-color: #3e8e41;
  border: 1px solid white;
  transform: translateY(4px);
}
</style>
        <!-- Font -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600" rel="stylesheet">
        <link rel="stylesheet" href="fonts/beyond_the_mountains-webfont.css" type="text/css"/>

        <!-- Stylesheets -->
        <link href="plugin-frameworks/bootstrap.min.css" rel="stylesheet">
        <link href="plugin-frameworks/swiper.css" rel="stylesheet">
        <link href="fonts/ionicons.css" rel="stylesheet">
        <link href="common/styles.css" rel="stylesheet">
        <link href="drop.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js" ></script>
<script src="my.js"></script>
</head>
<body onload="showHeader()">
<div id="header-comp" ></div>
<section class="bg-5 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                                <h5><b>ЛУЧШИЙ В ГОРОДЕ</b></h5>
                                <h2 class="mt-30 mb-15">Menu</h2>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>

<section class="story-area left-text center-sm-text">
        <div class="container">
                <div class="heading"><h3>Pizza</h3></div>
                <div class="row">
<?php
$pizza=$db->query("SELECT * FROM catalog WHERE Вид LIKE '1'");
while ($row = $pizza->fetch_assoc())
{
?>
                        <div class="col-lg-3 col-md-4  col-sm-6 " >
                                <div class="center-text mb-30" >
                                <a name="<?php echo $row['id'];?>"></a>
                                        <div class="ïmg-200x mlr-auto pos-relative" >
                                                <!--<h6 class="ribbon-cont color-white"><div class="ribbon primary"></div><b>OFFER</b></h6>-->
                                                <img src="<?php echo $row['Изображение'];?>" alt="">

                                        </div>
                                        <h4 class="mt-20"><?php echo $row['Наименование'];?></h4>
                                        <?php if(isset($_SESSION['adminind'])){if($_SESSION['adminind']){ ?><div  style="padding-top:10%; ">
                                        <h5 class="mb-20" ><input type="button" class="button" onClick="addToCart(<?php echo $row['id'];?>)" href="#" class="btn-brdr-primary float-center" style=" padding-right: 2%;padding-left: 2%;" value="<?php echo $row['Цена']; ?> р."></input></h5>
                                        </div><?php }} ?>

                                        <h6 class="mt-20"><?php echo $row['Описание'];?></h6>

                                <!--text-center-->
                                </div>
                        </div><!-- col-md-3 -->

<?php } ?>

                </div><!-- row-->
        </div><!-- container -->
</section>



<section class="story-area bg-seller color-white pos-relative">
        <div class="pos-bottom triangle-up"></div>
        <div class="pos-top triangle-bottom"></div>
        <div class="container">
                <h4 class="font-30 font-sm-20  center-text mb-25">Добавте свежий <b>Салат</b> в ваш заказ</h4>
        </div><!-- container -->
</section>
<section class="story-area left-text center-sm-text">
        <div class="container">
                <div class="heading"><h3>Salads</h3></div>
                <div class="row">
<?php
$salads=$db->query("SELECT * FROM catalog WHERE Вид LIKE '2'");
while ($row = $salads->fetch_assoc())
{
?>
                        <div class="col-lg-3 col-md-4  col-sm-6 " >
                                <div class="center-text mb-30" >
                                <a name="<?php echo $row['id'];?>"></a>
                                        <div class="ïmg-200x mlr-auto pos-relative" >
                                                <!--<h6 class="ribbon-cont color-white"><div class="ribbon primary"></div><b>OFFER</b></h6>-->
                                                <img src="<?php echo $row['Изображение'];?>" alt="">

                                        </div>
                                        <h4 class="mt-20"><?php echo $row['Наименование'];?></h4>
                                        <?php if(isset($_SESSION['adminind'])){if($_SESSION['adminind']){ ?><div  style="padding-top:10%; ">
                                        <h5 class="mb-20" ><input type="button" class="button" onClick="addToCart(<?php echo $row['id'];?>)" href="#" class="btn-brdr-primary float-center" style=" padding-right: 2%;padding-left: 2%;" value="<?php echo $row['Цена']; ?> р."></input></h5>
                                        </div><?php }} ?>
                                        <h6 class="mt-20"><?php echo $row['Описание'];?></h6>
                                <!--text-center-->
                                </div>
                        </div><!-- col-md-3 -->

<?php } ?>

                </div><!-- row-->
        </div><!-- container -->
</section>


        <section class="story-area left-text center-sm-text">
        <div class="container">
                <div class="heading"><h3>Pasta</h3></div>
                <div class="row">
<?php
$pasta=$db->query("SELECT * FROM catalog WHERE Вид LIKE '3'");
while ($row = $pasta->fetch_assoc())
{
?>
                        <div class="col-lg-3 col-md-4  col-sm-6 " >
                                <div class="center-text mb-30" >
                                <a name="<?php echo $row['id'];?>"></a>
                                        <div class="ïmg-200x mlr-auto pos-relative" >
                                                <!--<h6 class="ribbon-cont color-white"><div class="ribbon primary"></div><b>OFFER</b></h6>-->
                                                <img src="<?php echo $row['Изображение'];?>" alt="">

                                        </div>
                                        <h4 class="mt-20"><?php echo $row['Наименование'];?></h4>
                                        <?php if(isset($_SESSION['adminind'])){ if($_SESSION['adminind']){ ?><div  style="padding-top:10%; ">
                                        <h5 class="mb-20" ><input type="button" class="button" onClick="addToCart(<?php echo $row['id'];?>)" href="#" class="btn-brdr-primary float-center" style=" padding-right: 2%;padding-left: 2%;" value="<?php echo $row['Цена']; ?> р."></input></h5>
                                        </div><?php }} ?>
                                        <h6 class="mt-20"><?php echo $row['Описание'];?></h6>
                                <!--text-center-->
                                </div>
                        </div><!-- col-md-3 -->

<?php } ?>

                </div><!-- row-->
        </div><!-- container -->
</section>


<section class="story-area left-text center-sm-text">
        <div class="container">
                <div class="heading"><h3>Seafood</h3></div>
                <div class="row">
<?php
$seafood=$db->query("SELECT * FROM catalog WHERE Вид LIKE '4'");
while ($row = $seafood->fetch_assoc())
{
?>
                        <div class="col-lg-3 col-md-4  col-sm-6 " >
                                <div class="center-text mb-30" >
                                <a name="<?php echo $row['id'];?>"></a>
                                        <div class="ïmg-200x mlr-auto pos-relative" >
                                                <!--<h6 class="ribbon-cont color-white"><div class="ribbon primary"></div><b>OFFER</b></h6>-->
                                                <img src="<?php echo $row['Изображение'];?>" alt="">

                                        </div>
                                        <h4 class="mt-20"><?php echo $row['Наименование'];?></h4>
                                        <?php if(isset($_SESSION['adminind'])){if($_SESSION['adminind']){ ?><div  style="padding-top:10%; ">
                                        <h5 class="mb-20" ><input type="button" class="button" onClick="addToCart(<?php echo $row['id'];?>)" href="#" class="btn-brdr-primary float-center" style=" padding-right: 2%;padding-left: 2%;" value="<?php echo $row['Цена']; ?> р."></input></h5>
                                        </div> <?php }} ?>
                                        <h6 class="mt-20"><?php echo $row['Описание'];?></h6>
                                <!--text-center-->
                                </div>
                        </div><!-- col-md-3 -->

<?php } ?>

                </div><!-- row-->
        </div><!-- container -->
</section>

<section class="story-area bg-seller color-white pos-relative">
        <div class="pos-bottom triangle-up"></div>
        <div class="pos-top triangle-bottom"></div>
        <div class="container">
                <h4 class="font-30 font-sm-20  center-text mb-25">Добавте сладкий <b>Десерт</b> в ваш заказ</h4>
        </div><!-- container -->
</section>

<section class="story-area left-text center-sm-text">
        <div class="container">
                <div class="heading"><h3>Deserts</h3></div>
                <div class="row">
<?php
$deserts=$db->query("SELECT * FROM catalog WHERE Вид LIKE '5'");
while ($row = $deserts->fetch_assoc())
{
?>
                        <div class="col-lg-3 col-md-4  col-sm-6 " >
                                <div class="center-text mb-30" >
                                <a name="<?php echo $row['id'];?>"></a>
                                        <div class="ïmg-200x mlr-auto pos-relative" >
                                                <!--<h6 class="ribbon-cont color-white"><div class="ribbon primary"></div><b>OFFER</b></h6>-->
                                                <img src="<?php echo $row['Изображение'];?>" alt="">

                                        </div>
                                        <h4 class="mt-20"><?php echo $row['Наименование'];?></h4>
                                        <?php if(isset($_SESSION['adminind'])){if($_SESSION['adminind']){ ?><div  style="padding-top:10%; ">
                                        <h5 class="mb-20" ><input type="button" class="button" onClick="addToCart(<?php echo $row['id'];?>)" href="#" class="btn-brdr-primary float-center" style=" padding-right: 2%;padding-left: 2%;" value="<?php echo $row['Цена']; ?> р."></input></h5>
                                        </div><?php }} ?>
                                        <h6 class="mt-20"><?php echo $row['Описание'];?></h6>
                                <!--text-center-->
                                </div>
                        </div><!-- col-md-3 -->

<?php } ?>

                </div><!-- row-->
        </div><!-- container -->
</section>



                </div><!-- row -->
        </div><!-- container -->
</section>


<footer class="pb-50  pt-70 pos-relative">
        <div class="pos-top triangle-bottom"></div>
        <div class="container-fluid">
                <a href="index.html"><img src="images/heading.png"  alt="Logo"></a><br><br>
                        <h3>IL PIACERE</h3>
                <div class="pt-30">
                        <p class="underline-secondary"><b>Адрес:</b></p>
                        <p> Москва, улица Знаменка, Здание 4 </p>
                </div>

                <div class="pt-30">
                        <p class="underline-secondary mb-10"><b>Телефон:</b></p>
                        <a href="tel:+7 915 411 42 46 ">+7 915 411 42 46 </a>
                </div>

                <div class="pt-30">
                        <p class="underline-secondary mb-10"><b>Почта:</b></p>
                        <a href="mailto:matveev-vo@ya.ru"> matveev-vo@ya.ru</a>
                </div>

                <ul class="icon mt-30">
                        <li><a href="https://www.pinterest.ru/"><i class="ion-social-pinterest"></i></a></li>
                        <li><a href="https://ru-ru.facebook.com/"><i class="ion-social-facebook"></i></a></li>
                        <li><a href="https://twitter.com/?lang=ru"><i class="ion-social-twitter"></i></a></li>
                        <li><a href="https://dribbble.com/byoutline"><i class="ion-social-dribbble-outline"></i></a></li>
                        <li><a href="https://www.youtube.com/"><i class="ion-social-youtube"></i></a></li>
                </ul>

                <p class="color-light font-9 mt-50 mt-sm-30">
Авторское право &copy;<script>document.write(new Date().getFullYear());</script> Все права защищены
</p>
        </div><!-- container -->
</footer>


<!-- SCIPTS -->
<script src="plugin-frameworks/jquery-3.2.1.min.js"></script>
<script src="plugin-frameworks/bootstrap.min.js"></script>
<script src="plugin-frameworks/swiper.js"></script>
<script src="common/scripts.js"></script>
</body>
</html>