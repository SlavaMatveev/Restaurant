<?php
   
                    function protect_page(){
if (logged_in() === false ) {
            echo "<script>alert('Вы не можете сюда войти,зарегистрируйтесь!');window.location.href='../index.php';</script>"; 
        }
     }
 function protect_page2(){
 if (logged_in2() === true ) {
            echo "window.location.href='../index.php';</script>"; 
        }
    }

     
function logged_in(){
        return(isset($_SESSION['adminind'])) ? true : false;
    }
function logged_in2(){
        return(isset($_SESSION['ad_id'])) ? true : false;
    }


    
            ?>
