<?php 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
include 'session.php';
include 'security.php';
protect_page();
$cart = $_SESSION['cart'];
include 'loading.php';
 ?>
 <head><title>IL PIACERE:Заказ</title></head>
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 <link rel="icon" href="images/heading.ico" type="image/x-icon">
<html>
<style>
.button {
  padding: 10px 20px;
  font-size: 15px;
  text-align: center;

  cursor: pointer;
  outline: none;
  color: #EF0031;
  background-color: white;
  border: 1px solid #EF0031;

}
 .button:hover {background-color: #EF0031;
color: white;
 }

.button:active {
  background-color: #EF0031;
  border: 1px solid white;
  transform: translateY(4px);
}
.button1{

  border-radius: 50%; 
  width: 45px;
  height: 45px;
}
.buttong {
  padding: 10px 20px;
  font-size: 15px;
  text-align: center;

  cursor: pointer;
  outline: none;
  color: #3e8e41;
  background-color: white;
  border: 1px solid #3e8e41;

}
 .buttong:hover {background-color: #3e8e41;
color: white;
 }

.buttong:active {
  background-color: #3e8e41;
  border: 1px solid white;
  transform: translateY(4px);
}
</style>
<body >
<?php
include('header.php');
?>
<section class="bg-7 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                                <h3 class="mt-30 mb-15">Order</h3>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>
<div class="container"  style=" color:#321414; font-size: 20px;">
  <div class="row" >
    <div class="col" style="margin-top: 3%;">

      <form method="POST" action="#" class="was-validated" id="form_order">
      <fieldset>
  <div class="form-group">
     <label for="address">Ваш адрес:</label>
     <input type="text" name="address" class="form-control" id="address" required>
  </div>

   </fieldset>
     
  </form>
    </div>
    <div class="col" style="margin-top: 3%;">

      <?php 
$min = 100000000;
$max = 999999999;
$number_zakaz = rand($min, $max);
$prod_or="";
$allProducts=0;
$total=0;
$pizza1=0;
$salads1=0;
$seafood1=0;
$deserts1=0;
$pasta1=0;
  foreach ($cart as $idProduct => $num) {
                  $allProducts+=$num;
                  $query = 'select * from catalog where id = '.$idProduct.' ';
                  $results = $db->query($query);
                  while($row=$results->fetch_assoc()) {
                    $view=$row["Вид"];
                    $tot = 0;
                    $tot += $num*$row["Цена"];

$result6=$db->query("SELECT * FROM view ");
while ($rows = $result6->fetch_assoc())
{
  $rows['id'];
 switch ($rows['id']) {
    case 1:
        $pizza=$rows['count'];
        break;
    case 2:
        $pasta=$rows['count'];
        break;
    case 3:
        $salads=$rows['count'];
        
        break;
    case 4:
        $seafood=$rows['count'];
        break;
    case 5:
        $deserts=$rows['count'];
        break;
                  } 


    }
                    echo ' 
                      <div class="container-shop-product">
                        <hr style="width: 85%; margin: 0 auto;">
                      </div>
                      <div class="row_v2">
                        <div class="col"><br>
                          <h5>'.$row["Наименование"].'</h5>
                           <h5>Количество:<a style="color:#EF0031">'.$num.'</a></h5>';
                           $prod_or=$prod_or.', '.$row["Наименование"].' - '.$num;
                          echo '
                          <span class="f-s20">Сумма: <span class="f-w600"><a style="color:#EF0031">'.$tot.' руб.</a></span></span>
                        </div>
                        <div class="col" style="max-width: 250px;">
                          <div class="row pd-t5">
                            <div class="col-sm"></div>
                          </div><br>
                        </div>
                      </div>
                     ';
                    $total += $tot;
                    
if($view==1){

         $pizza1+=$num;
}
if($view==2){
     $pasta1+=$num;
         
}
if($view==3){
    $salads1+=$num;
         
}
if($view==4){
    $seafood1+=$num;
       
}
if($view==5){
    $deserts1+=$num;
        
}
                  }
                }
            $_SESSION['pizza']=$pizza1+$pizza;
            $_SESSION['$salads']=$salads1+$salads;
            $_SESSION['$seafood']=$seafood1+$seafood;
            $_SESSION['deserts']=$deserts1+$deserts;
            $_SESSION['$pasta']=$pasta1+$pasta;
              ?>
<?php 
  echo '<div style="border:1px solid #321414">Общая сумма:<a style="color:#EF0031"> '.$total.' руб</a></div>';
 ?>
    </div>
  </div>
  <br>

  <a class="button" href="Корзина.php">Вернуться в корзину</a>
  <input form="form_order" class="buttong" type="submit" name="submit" id="submit" value="Оформить заказ"> 
<?php
if(isset($_SESSION['adminind'])){ $id=$_SESSION['adminind'];
  $result1 = $db->query("SELECT * FROM `accounts` WHERE `id` LIKE '%$id%'");
  while ($row = $result1->fetch_assoc())
{

$ph=$row['Телефон'];
$email=$row['Логин'];

}
}

  if (isset($_POST['submit'])){
if(preg_match('/^[A-Za-zА-Яа-я0-9_., ]{1,100}$/u', $_POST['address'])==true){

$ad=$_POST['address'];
$pizza=$_SESSION['pizza'];
  $salads=$_SESSION['$salads'];
          $seafood=  $_SESSION['$seafood'];
           $deserts= $_SESSION['deserts'];
            $pasta= $_SESSION['$pasta'];
$_SESSION['pizza']="";
$_SESSION['$salads']="";
$_SESSION['$seafood']="";
$_SESSION['deserts']="";
$_SESSION['$pasta']="";
$db->query("INSERT INTO `orders` (`Номер заказа`,`Телефон клиента`,`Адрес`,`order_num`,`Сумма к оплате`,`Принято`,`Готово`,`id_client`) VALUES (NULL,'$ph','$ad','$number_zakaz','$total',NOW(),NULL,'$id')");
$db->query("UPDATE `view` SET `count`='$pizza' WHERE `Вид` LIKE 'pizza' ;");
$db->query("UPDATE `view` SET `count`='$salads' WHERE `Вид` LIKE 'salads' ;");
$db->query("UPDATE `view` SET `count`='$seafood' WHERE `Вид` LIKE 'seafood' ;");
$db->query("UPDATE `view` SET `count`='$deserts' WHERE `Вид` LIKE 'deserts' ;");
$db->query("UPDATE `view` SET `count`='$pasta' WHERE `Вид` LIKE 'pasta' ;");
foreach ($cart as $idp => $num) {
    $results2 = $db->query("SELECT * FROM catalog WHERE id = '$idp'");
    while($row=$results2->fetch_assoc()) { $number_product = $row['id'];}
    $data[] = "($number_zakaz, $number_product, '$num')";
}
$query = "INSERT INTO order_prod (id_order, id_catalog, count) VALUES " . implode(', ', $data) . " ";
$result3 = $db->query($query);

//почта
$mail = new PHPMailer();
$mail->CharSet = 'UTF-8';
$yourEmail = 'matveev-vo@ya.ru'; // ваш email на яндексе
$password1 = 'golggrcxqtrluojf'; // ваш пароль к яндексу или пароль приложения
// настройки SMTP
$mail->Mailer = 'smtp';
$mail->Host = 'ssl://smtp.yandex.ru';
$mail->Port = 465;
$mail->SMTPAuth = true;
$mail->Username = $yourEmail; // ваш email - тот же что и в поле From:
$mail->Password = $password1; // ваш пароль;
// формируем письмо
// от кого: это поле должно быть равно вашему email иначе будет ошибка
$mail->setFrom($yourEmail, 'IL_PIACERE');
// кому - получатель письма
$mail->addAddress($email, $fio);  // кому

$mail->Subject = 'Заказ';  // тема письма

$mail->msgHTML("<html><body>
            <h1>Ваш номер заказа: $number_zakaz</h1>
            <p>Телефон клиента:$ph</p>
            <p>Адрес:$ad</p>
            <p>Заказ:$prod_or</p>
            <p>Сумма к оплате:$total</p>
            <p>Это автоматическое письмо, просим вас не отвечать на него.</p>
            </html></body>");


if ($mail->send()) { // отправляем письмо
    echo "<script>alert('Письмо отправлено!');</script>";
} else {
    echo 'Ошибка: ' . $mail->ErrorInfo;
}
//

echo "<script>window.location.href='Complite.php'</script>";

}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}
?>
  <br>  <br>
</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>