<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
include 'session.php';
include 'security.php';
protect_page(); ?>
<head><title>IL PIACERE:Мой профиль</title></head>
<?php include ("header.php");
include 'loading.php';
?>
<head><title>IL PIACERE:Мой профиль</title></head>
<body>
  <link href="profile.css" rel="stylesheet">
<section class="bg-4 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                           <h3 class="mt-30 mb-15">My profile</h3>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>
<section class="story-area left-text center-sm-text">
        <?php
        if(isset($_SESSION['adminind'])){ $id=$_SESSION['adminind'];

$result = $db->query("SELECT * FROM `accounts` WHERE `id` LIKE '$id'");
while ($row2 = $result->fetch_assoc())
{
$log1=$row2['Логин'];
 $fio1=$row2['ФИО'];
$ph1=$row2['Телефон'];
} 
}
if(isset($_POST['submit'])){
if(isset($_SESSION['login'])){ $log=$_SESSION['login'];
if(preg_match('/^[A-Za-zА-Яа-я ]{0,85}$/u', $_POST['fio'])==true){
if(preg_match('/^[+]+[7]+[0-9]{10,12}$/u', $_POST['phone'])==true){
if(preg_match('/^[A-Za-zА-Яа-я0-9_.]{1,20}$/u', $_POST['password'])==true){
$fio=$_POST['fio'];
$ph=$_POST['phone'];
$pas=$_POST['password'];

    if($pas==""){
$result1 = $db->query("UPDATE `accounts` SET `ФИО`='$fio', `Телефон`='$ph' WHERE id LIKE '$id' ;");
$_SESSION['fio'] = $fio;

  echo '<meta http-equiv="refresh" content="1; URL=index.php" />';
    }
    else{
    $result1 = $db->query("UPDATE `accounts` SET `Пароль`=MD5('$pas'),`ФИО`='$fio', `Телефон`='$ph' WHERE id LIKE '$id' ;");
  
$mail = new PHPMailer();
$mail->CharSet = 'UTF-8';
$yourEmail = 'matveev-vo@ya.ru'; // ваш email на яндексе
$password1 = 'golggrcxqtrluojf'; // ваш пароль к яндексу или пароль приложения
// настройки SMTP
$mail->Mailer = 'smtp';
$mail->Host = 'ssl://smtp.yandex.ru';
$mail->Port = 465;
$mail->SMTPAuth = true;
$mail->Username = $yourEmail; // ваш email - тот же что и в поле From:
$mail->Password = $password1; // ваш пароль;
// формируем письмо
// от кого: это поле должно быть равно вашему email иначе будет ошибка
$mail->setFrom($yourEmail, 'IL_PIACERE');
// кому - получатель письма
$mail->addAddress($log, $fio); // кому

$mail->Subject = 'Уведомление о редактировании!'; // тема письма

$mail->msgHTML('
<html>
<head>
<title>Ваши персональные данные были изменены!</title>
</head>
<body>
<p>Если вы не меняли персональне данные, обратитесь в службу поддержки matveev-vo@ya.ru </p>
</body>
</html>
');
if ($mail->send()) { // отправляем письмо



echo '<meta http-equiv="refresh" content="1; URL=index.php" />';
} else {
echo 'Ошибка: ' . $mail->ErrorInfo;
}
$_SESSION['fio'] = $fio;

  echo '<meta http-equiv="refresh" content="1; URL=index.php" />';}

}else{
echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}else{
echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}else{
echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}}
}else{$fio=0;}
$pizza=$db->query("SELECT * FROM `accounts` WHERE `ФИО` LIKE '$fio';");
while ($row = $pizza->fetch_assoc())
{
  $_SESSION['adminind']=$row['id'];
}

?>  


        <div class="container">
                
<form method="post" style="" class="was-validated">
  <div class="form-group">
    <label for="fio">ФИО</label>
    <input type="text"name="fio" value='<?php echo $fio1; ?>' class="form-control" id="fio" placeholder="Введите вашу фамилию" required pattern="[A-Za-zА-Яа-я ]{0,85}" />
  </div>
  
  <div class="form-group">
    <label for="phone">Телефон</label>
    <input type="text"name="phone" value='<?php echo $ph1; ?>' class="form-control" id="phone" placeholder="Введите ваш телефон" required pattern="[+]+[7]+[0-9]{10,12}" />
  </div>
  <div class="form-group">
    <label for="password">Пароль</label>
    <input type="password" name="password"  class="form-control" id="password" placeholder="Введите пароль"  pattern="[A-Za-zА-Яа-я0-9_.]{1,20}" />
  </div>
  <br>
  <input type="submit" name="submit" class="btn btn-primary" /></input>
  
</form> 
</div>
</section>



<?php

include("footer.php"); ?>

