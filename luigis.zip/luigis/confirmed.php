<?php
include 'session.php';
include 'loading.php';
//protect_page2();?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?php

 if($_GET['hash']){

$hash = $_GET['hash']; 
    // Получаем id и подтверждено ли Email
$result1 = $db->query("SELECT * FROM `accounts` WHERE `hash` LIKE '$hash'");

while ($rows = $result1->fetch_assoc())
{ 
if($rows['email_confirm'] == NULL){ 
    $id=$rows['id'];
    $fio=$rows['ФИО'];
    $log=$rows['Логин'];
    $pas=$rows['Пароль'];
$result2 = $db->query("UPDATE `accounts` SET `email_confirm`= MD5(1) WHERE `id` LIKE '$id' AND `ФИО` LIKE '$fio' AND `Логин` LIKE '$log' AND `Пароль` LIKE '$pas';");
$_SESSION['adminind'] = $rows['id'];
$_SESSION['fio'] = $fio;
$_SESSION['login']= $log;
$_SESSION['password']= $pas;
echo "<script>alert('Почта подтверждена!')</script>";
echo '<meta http-equiv="refresh" content="1; URL=index.php" />';
    }else{
        echo "<script>alert('Почта уже подтверждена!')</script>";
        echo '<meta http-equiv="refresh" content="1; URL=index.php" />';
    }
}
}else{
        echo "<script>alert('Подтвердите по почте!')</script>";
        echo '<meta http-equiv="refresh" content="1; URL=index.php" />';
    }