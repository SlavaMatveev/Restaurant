<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
include 'session.php';?>
<head><title>IL PIACERE:API-авторизация</title></head>
<?php include ("header.php");
include 'security.php';

protect_page();
?>

</head>

<body>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?php
include 'loading.php';
if(isset($_SESSION['adminind'])){
$id=$_SESSION['adminind'];}

if(isset($_POST['submit'])){
if(preg_match('/^[^@\s]+@[^@\s]+\.[^@\s]+$/', $_POST['login'])==true){
if(preg_match('/^[A-Za-zА-Яа-я0-9_.]{1,20}$/', $_POST['password'])==true){
  
$log=$_POST['login'];
$pas=MD5($_POST['password']);
$flag=false;
$result1 = $db->query("SELECT * FROM accounts ");



while ($row = $result1->fetch_assoc())
{
$password=$row['Пароль'];
$login=$row['Логин'];


if($login == $log AND $password == $pas){

$api = md5($log . time());

$result3 = $db->query("UPDATE `accounts` SET `api_key`='$api' WHERE id LIKE '$id' ;");

$mail = new PHPMailer();
$mail->CharSet = 'UTF-8';
$yourEmail = 'matveev-vo@ya.ru'; // ваш email на яндексе
$password1 = 'golggrcxqtrluojf'; // ваш пароль к яндексу или пароль приложения
// настройки SMTP
$mail->Mailer = 'smtp';
$mail->Host = 'ssl://smtp.yandex.ru';
$mail->Port = 465;
$mail->SMTPAuth = true;
$mail->Username = $yourEmail; // ваш email - тот же что и в поле From:
$mail->Password = $password1; // ваш пароль;
// формируем письмо
// от кого: это поле должно быть равно вашему email иначе будет ошибка
$mail->setFrom($yourEmail, 'IL_PIACERE');
// кому - получатель письма
$mail->addAddress($log, 'Покупатель');  // кому

$mail->Subject = 'API-ключ';  // тема письма
$attachment = '..\luigis\mail\index.txt';
$mail->AddAttachment($attachment , 'index.txt');
$mail->msgHTML("<html><body>
            <h2>Ваш ключ:$api</h2>
            <p>для помощи введите http://n91541mu.beget.tech/index.php?api_key='ваш апи'&query=help</p>
            <p>Это автоматическое письмо, просим вас не отвечать на него.</p>
            </html></body>");


if ($mail->send()) { // отправляем письмо
    echo "<script>alert('Письмо отправлено!');</script>";
} else {
    echo 'Ошибка: ' . $mail->ErrorInfo;
}

$flag=true;
 unset($_SESSION['api_key']);
$_SESSION['api_key']=$api;
echo '<meta http-equiv="refresh" content="1; URL=index.php" />';
}


}
if($flag==false){
  echo "<script>alert('Неверный логин или пароль!');</script>";

  $flag=true;
}
}}else{
  echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";
}
}



?>  

<section class="bg-6 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                                <h3 class="mt-30 mb-15">API</h3>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>


<section class="story-area left-text center-sm-text">
        <div class="container">
               <form method="post" class="was-validated">
 <div class="form-group">
    <label for="login">Логин</label>
    <input type="text"name="login" class="form-control" title='Пример:primer@yandex.ru)' id="login" required pattern="[^@\s]+@[^@\s]+\.[^@\s]+"/  placeholder="Введите логин" />

  </div>
  <div class="form-group">
    <label for="password">Пароль</label>
    <input type="password" name="password" class="form-control" title='A-Z,a-z, ,а-я,.,_,A-Я (20 символов)' id="password" required pattern="[A-Za-zА-Яа-я0-9_.]{1,20}" placeholder="Пароль"/>
  </div>
  <input type="submit" name="submit" class="btn btn-primary" /></input>
</form> 
        </div><!-- container -->
</section>




</body>

<?php 
include('footer.php');
?>
