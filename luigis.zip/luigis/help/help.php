<?php  session_start(); 
include '../admin/security.php';
protect_page();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>IL PIACERE: Помощь</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="css/glitch.css">
	<link rel="stylesheet" href="css/Styles.css">
</head>
<body >
	<style type="text/css">

		
	</style>
	  <section class="bg-4 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                                <h5><b>ЛУЧШИЙ В ГОРОДЕ</b></h5>
                                <h2 class="mt-30 mb-15">Help</h2>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>
	<? include ('header.php')?>

	<div class="wrapper" style="padding: 30px; min-height: 550px;">

		<div style="height: 500px; margin-top: 15px;">
			<iframe src="menu.php" width="20%" align="left" style="height: 500px"></iframe>
			<iframe src="text.php" width="80%" name="main" style="height: 500px"></iframe>
		</div>
	</div>
	<style type="text/css">
		.footer { position: relative; width: 100%; z-index: 7; height: auto; background-color: #121212; text-align: center; min-height: 140px; padding-top: 2rem!important; }
		.colorbottom { position: relative; height: 5px; width: 100%; background: linear-gradient(90deg,#5ff9fc,#69a5dc 23.5%,#b460c6 69.44%,#f232b1); transform: matrix(1,0,0,-1,0,0); }
		.aorus-copyright-div { position: relative; z-index: 7; color: #fff; background: #000; }
		.flex-container { display: flex; justify-content: space-between; }
		.copyright-container { position: relative; margin: 0 auto; max-width: 1920px; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto; }
		.copyright { display: inline-flex; font-style: normal; font-weight: 500; text-transform: capitalize; font-size: 14px; color: #c4c4c4; text-align: right; }
	</style>


	
</body>
</html>