<?php  session_start(); 
include '../admin/security.php';
protect_page();
?>
<!DOCTYPE html> 
<html>
<head>
		<title>Файл menu.html - меню сайта</title>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>


		<style>

		</style>
</head>
<body >
		<div style="padding: 8px;">
			<p style=" font-size: 24px; font-weight: 600; text-align: center;">СОДЕРЖАНИЕ</p>
				<ul style="font-size: 20px; font-weight: 500; list-style-type: none;">
						<li><a class="btn btn-danger" target="main" href="text.php#gl1" style="color: #fff; margin-bottom: 5px; text-decoration: none; width: 90%;">О программе</a></li>
						<li><a class="btn btn-danger" target="main" href="text.php#gl6" style="color: #fff; margin-bottom: 5px; text-decoration: none; width: 90%;">Навигация по сайту</a></li>
						<li><a class="btn btn-danger" target="main" href="text.php#gl2" style="color: #fff; margin-bottom: 5px; text-decoration: none; width: 90%;">Страницы отображения</a></li>
						<li><a class="btn btn-danger" target="main" href="text.php#gl3" style="color: #fff; margin-bottom: 5px; text-decoration: none; width: 90%;">Страницы добавления</a></li>
						<li><a class="btn btn-danger" target="main" href="text.php#gl4" style="color: #fff; margin-bottom: 5px; text-decoration: none; width: 90%;">Страницы изменения</a></li>
						<li><a class="btn btn-danger" target="main" href="text.php#gl5" style="color: #fff; margin-bottom: 5px; text-decoration: none; width: 90%;">Безопасность</a></li>
						<li><a class="btn btn-danger" target="main" href="text.php#gl7" style="color: #fff; margin-bottom: 5px; text-decoration: none; width: 90%;">Правила использования</a></li>
						
				</ul>
		</div>
		<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
</body>
</html>