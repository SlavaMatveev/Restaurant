<?php  session_start(); 
include '../admin/security.php';
protect_page();
?>
<!DOCTYPE html>
<html>
<head>
	<title>ссылки</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>


	<style>
		b{text-align: center;}
	</style>
</head>
<body >
	<div class="wrapper"  style="padding: 30px; ">
		<p style="text-align: center;">
			<font size="6">
				<b>Справка</b>
			</font>
		</p>
		<div style="margin-top: 50px; border-bottom: 1px solid #666;">
			<a name="gl1">
				<p style="text-align: center;">
					<font size="5">
						<b>1. О программе</b>
					</font>
				</p>
				<p class="jus">
					<font size="3" >Данный программный продукт предназначен для коммерческого использования в целях регулирования контента на приложенном сайте: Программа не является отдельным продуктом, она входит в состав веб приложения для ресторана IL PIACERE. 
						Панель администрирования необходима для того, чтобы взаимодействовать с информацией, хранящейся на сервере. Администратор вправе изменять, удалять и добавлять информацию на сервер, функции предусмотрены.<br><br>
						Для того чтобы начать работу, прочтите разделы ниже, для удобного перехода к ним есть меню в левой части окна.
					</font>
				</p>
			</a>
		</div>
		<div style="margin-top: 50px; border-bottom: 1px solid #666;">
			<a name="gl6">
				<p style="text-align: center;">
					<font size="5">
						<b>2. Навигация по сайту</b>
					</font>
				</p>
				<p class="jus">
					<font size="3">Навигация по сайту осуществяется через панель навигации в верхней части сайта (см. рисунок 1). 
						<br><center><img width="800px" align="center" src="Панель навигации .jpg"></center><center>Рисунок 1 - Панель навигации</center>
						<br>Каждая кнопка отвечает за свою страницу с отображением таблиц. Самая правая кнопка на панели дает возможность выйти (см. рисунок 2) из учётной записи администратора. (см. рисунок 3).
						<br><center><img width="800px" align="center" src="Выход .jpg"></center><center>Рисунок 2 - Кнопка выхода</center><br>
						<br><center><img width="800px" align="center" src="Пользов .jpg"></center><center>Рисунок 3 - Пользовательский сайт</center><br>
						Самая левая кнопка, ярко выраженная красным цветом, является переходом на Пользовательскую часть сайта, с урезанным функционалом:заказ,корзина,обратная связь и тд. Что администратору не является необходимым (см. рисунок 4). 
						<br><center><img width="800px" align="center" src="Сайт.jpg"></center><center>Рисунок 4 - Администрационная версия сайта</center><br>
					</font>
				</p>
			</a>
		</div>
		<div style="margin-top: 50px; border-bottom: 1px solid #666;">
			<a name="gl2">
				<p style="text-align: center;">
					<font size="5">
						<b>3. Страницы отображения</b>
					</font>
				</p>
				<p class="jus">
					<font size="3">На страницах просмотра есть таблицы (см. рисунок 5) с кнопками "Изменить" и "Удалить" при нажатии на которые происходят соответственно изменение записи и удаление.
						Изменение производится на отдельной странице (см. "<a target="main" href="text.php#gl4">Страницы изменения</a>"). Перед таблицей находятся кнопки "Фильтры" или строка поиска с кнопкой "Найти",
						кнопка "Отменить фильтры и поиск", которое сбрасывает все фильтры и поиск, кнопка "Добавить" для добавления новых строк в таблицу .
						<br><center><img width="800px" align="center" src="таблица .jpg"></center><center>Рисунок 5 - Таблица отображения</center><br>
						<br>Администратор может просматривать данные в таблицах, фильтровать содержимое по встроенным фильтрам (см. рисунок 6). Фильтры можно применять только по одному.
						<br><center><img width="400px" align="center" src="фильтры .jpg"></center><center>Рисунок 6 - Пример фильтров таблиц</center>
						<br>Для каждой страницы фильтры разные.
					</font>
				</p>
			</a>
		</div>
		<div style="margin-top: 50px; border-bottom: 1px solid #666;">
			<a name="gl3">
				<p style="text-align: center;">
					<font size="5">
						<b>4. Страницы добавления</b>
					</font>
				</p>
				<p class="jus">
					<font size="3">Страницы добавления предусмотрены во всех таблицах, кроме заказа. Заказ возможно добавить в базу только из пользовательского аккаунта.
						Добавление осуществляется через форму (см. рисунок 7), которую необходимо заполнить и отправить. Значок восклицательного знака в правой части поля говорит о том, что поле либо не заполнено, либо заполнено неверно. Для правильного заполнения смотрите подсказки при наведении на поле.
						<br><center><img width="800px" align="center" src="форма_добавления .jpg"></center><center>Рисунок 7 - Форма добавления</center>
					</font>
				</p>
				Изображение добавляется ТОЛЬКО скаченное, из буфера обмена не загрузится. После отправки формы в таблице появляется добавленная строка.
			</a>
		</div>
		<div style="margin-top: 50px; border-bottom: 1px solid #666;">
			<a name="gl4">
				<p style="text-align: center;">
					<font size="5">
						<b>5. Страницы изменения</b>
					</font>
				</p>
				<p class="jus">
					<font size="3">Страницы изменения предусмотрены во всех таблицах. Изменение происходит на отдельной странице и осуществяется с помощью формы (см. рисунок 8), в которую можно внести коррективы и отправить.
						<br><center><img width="800px" align="center" src="форма_изменения .jpg"></center><center>Рисунок 8 - Форма изменения</center>
						<br>Изображение добавляется ТОЛЬКО скаченное, из буфера обмена не загрузится. После отправки запись в таблице изменится на введенные данные.
					</font>
				</p>
			</a>
		</div>
		<div style="margin-top: 50px; border-bottom: 1px solid #666;">
			<a name="gl5">
				<p style="text-align: center;">
					<font size="5">
						<b>6. Безопасность</b>
					</font>
				</p>
				<p>
					<font size="3">На данном сайте реализовано хэширование паролей. Все пароли написаны в шифровке, это НЕ пароли, которые вводит пользователь или администратор сайта.</font>
				</p>
			</a>
		</div>
		<div style="margin-top: 50px; border-bottom: 1px solid #666;">
			<a name="gl7">
				<p style="text-align: center;">
					<font size="5">
						<b>7. Правила использования</b>
					</font>
				</p>
				<p>
					<font size="4">
					1. Без ведома пользователя, не изменять и не удалять его данные аккаунта!!!<br>
					2. Не создавать администраторов без ведома руководства!!!<br>
					3. Следить за актульностью акций и удалять и заменять их по мере необходимости.<br>
					4. Следить за продукцией и по мере необходимости добавлять, изменять и удалять ее из базы.
					</font>
				</p>
			</a>
		</div>
	</div>


</body>
</html>