<?php
include 'session.php';
?>
<!DOCTYPE html>
<html lang="en">
<link rel="icon" href="../images/heading.ico" type="image/x-icon">
<head >


        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">

        <!-- Font -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600" rel="stylesheet">
        <link rel="stylesheet" href="../fonts/beyond_the_mountains-webfont.css" type="text/css"/>

        <!-- Stylesheets -->
        <link href="../plugin-frameworks/bootstrap.min.css" rel="stylesheet">
        <link href="../plugin-frameworks/swiper.css" rel="stylesheet">
        <link href="../fonts/ionicons.css" rel="stylesheet">
        <link href="../common/styles.css" rel="stylesheet">
        <link href="../drop.css" rel="stylesheet">
      

</head>
<body>

<header style= "position: fixed;  top: 0; width: 100%;">

        <div class="container">

                <a class="logo" href="#"><img src="../images/logo.png" alt="Logo"></a>
                <div class="right-area">
                                            <h6>
<div class="dropdown">
  <svg  xmlns="http://www.w3.org/2000/svg"  width="50" height="50" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
  <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
  <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"/>
</svg>
<br>    <?php 
echo $_SESSION['fio'];
?>

<div class="dropdown-content">


  <ul style="text-align: center;" >
    <li ><a href="logout.php?do=logout" >Выйти</a></li>
  </ul>
</div>






                                                </h6>
                </div><!-- right-area -->


                <a class="menu-nav-icon" data-menu="#main-menu" href="#"><i class="ion-navicon"></i></a>

                <ul class="main-menu font-mountainsre" id="main-menu">
                			<li><div class="dropdown"><div class="cart"><a href="../index.php" class="plr-20 color-white btn-fill-primary">САЙТ</a></div></li>
                        <li><a href="../admin/accounts.php">АККАУНТЫ</a></li>
                        <li><a href="../admin/catalog.php">КАТАЛОГ</a></li>
                        <li><a href="../admin/message.php">СООБЩЕНИЯ</a></li>
                        <li><a href="../admin/orders.php">ЗАКАЗЫ</a></li>
								<li><a href="../admin/posts.php">ПОСТЫ</a></li>
								<li><a href="../admin/view.php">ВИД</a></li>
								<li><a href="../help/help.php"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-question-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
  <path d="M5.255 5.786a.237.237 0 0 0 .241.247h.825c.138 0 .248-.113.266-.25.09-.656.54-1.134 1.342-1.134.686 0 1.314.343 1.314 1.168 0 .635-.374.927-.965 1.371-.673.489-1.206 1.06-1.168 1.987l.003.217a.25.25 0 0 0 .25.246h.811a.25.25 0 0 0 .25-.25v-.105c0-.718.273-.927 1.01-1.486.609-.463 1.244-.977 1.244-2.056 0-1.511-1.276-2.241-2.673-2.241-1.267 0-2.655.59-2.75 2.286zm1.557 5.763c0 .533.425.927 1.01.927.609 0 1.028-.394 1.028-.927 0-.552-.42-.94-1.029-.94-.584 0-1.009.388-1.009.94z"/>
</svg></a></li>
                </ul>
                
                <div class="clearfix"></div>

        </div><!-- container -->

</header>
<style>
img { -moz-user-select: none; -webkit-user-select: none; -ms-user-select: none; user-select: none; }
.btn:focus {
outline: none;
box-shadow: none;
}
::-webkit-scrollbar {
  width: 0;
}
</style>
