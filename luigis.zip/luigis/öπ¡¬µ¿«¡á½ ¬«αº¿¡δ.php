<?php 
include 'session.php';
include 'loading.php';
include 'security.php';
protect_page();
  $action = $_POST["action"];
  if ($action == 'show') {
    if (!(isset($_SESSION['cart']))) {
      echo '<div style="text-align:center; width:100%; height:50% "><h2>Корзина пуста<h2></div>';
      exit;
    };
    $cart = $_SESSION['cart'];
    if (count($cart)==0) {
      echo '<div style="text-align:center; width:100%; height:50% "><h2>Корзина пуста<h2></div>';
      exit;
    }

    ?>
    <style type="text/css">
a.disabled {
    pointer-events: none; /* делаем ссылку некликабельной */
    cursor: default;  /* устанавливаем курсор в виде стрелки */
    color: #999; /* цвет текста для нективной ссылки */
}
.button {
  padding: 10px 20px;
  font-size: 15px;
  text-align: center;

  cursor: pointer;
  outline: none;
  color: #EF0031;
  background-color: white;
  border: 1px solid #EF0031;

}
 .button:hover {background-color: #EF0031;
color: white;
 }

.button:active {
  background-color: #EF0031;
  border: 1px solid white;
  transform: translateY(4px);
}
.button1{

  border-radius: 50%; 
  width: 45px;
  height: 45px;
}
.buttong {
  padding: 10px 20px;
  font-size: 15px;
  text-align: center;

  cursor: pointer;
  outline: none;
  color: #3e8e41;
  background-color: white;
  border: 1px solid #3e8e41;

}
 .buttong:hover {background-color: #3e8e41;
color: white;
 }

.buttong:active {
  background-color: #3e8e41;
  border: 1px solid white;
  transform: translateY(4px);
}
</style>
    <div class="row">
      <div class="container center-container2">
        <div class="wFull" style="position: relative; margin:0 25% 0 25%;">
          <div class="mr-t30 mr-r15 mr-l30 mr-b30" style=" display: inline-block;width:110% ">
            <div id="shopping" style="width: 100%;">
              <?php 
                //var_dump($cart);
              $allProducts=0;
              $tot=0;
                foreach ($cart as $idProduct => $num) {
                  //echo $idProduct.' '.$num.'<br>';
                  
                  $allProducts+=$num;
                  $query = 'select * from catalog where id = '.$idProduct.' ';
                  $results = $db->query($query);
                  while($row=$results->fetch_assoc()) {
                    

                    $tot += $num*$row["Цена"];
                    echo ' 
                      <div class="container-shop-product">
                        <hr style="width: 85%; margin: 0 auto;">
                      </div>
                      <div class="row_v2" style="">
                        <div style="margin: 1%; max-width: 250px;">
                          <img style="height:200px; width: 200px;" src="'.$row["Изображение"].'" alt="">
                        </div>
                        <div class="col" style="margin: 1%;"><br>
                          <h5>'.$row["Наименование"].'</h5>
                          <span class="f-s20" style="">Цена: <span class="f-w600"><a style="color:#EF0031">'.$row["Цена"].' руб.</a></span></span>
                        </div>
                        <div class="col" style="margin: 1%; max-width: 250px;">
                          <label for="">Количество:</label>
                          <div class="row pd-t5">
                            <div class="col-sm">
                              <div id="" class="ProductCardForUpsale__counter">
                                <button class="button button1" id="PlusOneProduct" onClick="delFromOne('.$row["id"].')">
                                  <svg class=" Icon Icon_size_xs" width="20" height="20" viewBox="0 0 20 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M3.25 9.25H16C16.4142 9.25 16.75 9.58579 16.75 10C16.75 10.4142 16.4142 10.75 16 10.75H3.25V9.25Z"></path>
                                  </svg>
                                </button>
                                
                                <input class="CountSelector__input" type="number" value="'.$num.'" min="1" max="30" step="1" data-step="1" readonly="true" required>
                                <button class="button button1" id="DelOneProduct" onClick="addToOne('.$row["id"].')">
                                  <svg class=" Icon Icon_size_xs" width="20" height="20" viewBox="0 0 20 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M10 3.25C10.4142 3.25 10.75 3.58579 10.75 4V9.25H16C16.4142 9.25 16.75 9.58579 16.75 10C16.75 10.4142 16.4142 10.75 16 10.75H10.75V16.75H9.25V10.75H3.25V9.25H9.25V4C9.25 3.58579 9.58579 3.25 10 3.25Z"></path>
                                  </svg>
                                </button>
                              </div>
                              <br>
                              <br><h5 class="mb-10" ><input type="button" class="button"  value="Удалить товар" onClick="delFromCart('.$row["id"].')" href="#" ></h5>
                            </div>
                          </div><br>
                        </div>
                      </div>
                     ';
                     if ($num<'1') {
                      echo "<script>
                      document.getElementById('btn').addEventListener('click', function(e) {
                         e.preventDefault();
                      }, false);
                      delFromCart(".$row['id']."); 
                      </script>";}
                  }
                }

              ?>
            </div>
          </div>
          <div class="mr-t30 mr-r15 mr-l30 mr-b30" style="height: auto;  min-height: 400px; vertical-align: top; ">
            <div class=" OrderFinalPrice" style="padding: 25px 25px; background: white;text-align: center;margin:0 10% 0 10%; ">
              <div id="shopping_counter">
                <?php 
                  echo ' 
                    <div class="f-s26 f-w600">В корзине</div>
                    <div class="f-s18" ><a style="color:#EF0031">'.$allProducts.' </a> товаров</div>
                    <div class="pd-t15">
                      <div>
                        <span class="f-s22 f-w600" >Cумма: <a style="color:#EF0031">'.$tot.' руб.</a><span></span></span>
                      </div>
                      <div class="mr-b10 mr-t10" style="border-top: 1px solid #888;"></div>
                      <br>
                      <form class="oform" style="background-color: white; width: auto; margin: 0 auto;">
                        <a type="btn" class="buttong"  id="btn" href="Заказ.php">Оформить заказ
                        </a>
                      </form>
                      <br>
                      <div style="background-color: white; width: auto; margin: 0 auto;">
                      <a type="btn" class="button"  href="Delete.php">Очистить корзину</a>
                      </div>
                    </div>
                   ';
                 ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  <?php
  }

  $statot = 0;
  $statot += $tot;
  $arrayStat = array($statot,$allProducts);
  //echo $arrayStat[0];

  $_SESSION['arr'] = $arrayStat;

  ##############
  if ($action == 'add') {
    //Считываем уже имеющуюся корзину
    $cart = $_SESSION['cart'];
    //Считываем id товара который надо добавить
    $id = $_POST['id'];
    //Есть ли товар с таким id в корзине 
    if(isset($cart[$id])) {
      //товар уже в корзине - увел кол-во его в корзине 
      $cart[$id]++;
    } else {
      //товара в корзинке нет добавляем новый :)
      //По умолчанию будем добавлять 1 ед товара
      $cart[$id] = 1;
    }
    //По умолчанию добавялем товар в корзину колво 1 шт
    $_SESSION['cart'] = $cart;
  }

  if ($action == 'del') {
    //получаем id продукта
    $id = $_POST['id'];
    //имеющаяся корзина
    $cart = $_SESSION['cart'];
    // уничтожить элемент корзины с данным id
    unset($cart[$id]);
    $_SESSION['cart'] = $cart;
  }

  if ($action == 'delOne') {
    //получаем id продукта
    $id = $_POST['id'];
    //имеющаяся корзина
    $cart = $_SESSION['cart'];
    // уничтожить элемент корзины с данным id
    if(isset($cart[$id])) {
      //товар уже в корзине - увел кол-во его в корзине 
      $cart[$id]--;
    } else {
      //товара в корзинке нет добавляем новый :)
      //По умолчанию будем добавлять 1 ед товара
      $cart[$id] = 1;
    }
    $_SESSION['cart'] = $cart;
  }

  if ($action == 'addOne') {
    //получаем id продукта
    $id = $_POST['id'];
    //имеющаяся корзина
    $cart = $_SESSION['cart'];
    // уничтожить элемент корзины с данным id
    if(isset($cart[$id])) {
      //товар уже в корзине - увел кол-во его в корзине 
      $cart[$id]++;
    } else {
      //товара в корзинке нет добавляем новый :)
      //По умолчанию будем добавлять 1 ед товара
      $cart[$id] = 1;
    }
    $_SESSION['cart'] = $cart;
  }

 ?>
