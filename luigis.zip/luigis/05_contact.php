<?php
include 'session.php';
include 'security.php';
include 'loading.php';
protect_page();
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<head><title>IL PIACERE:Контакт</title></head>
<?php
include 'header.php';
?>

<style>

.button {
  padding: 15px 25px;
  font-size: 24px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #EF0031;
  background-color: white;
  border: 1px solid #EF0031;

}
 .button:hover {background-color: #EF0031;
color: white;
 }

.button:active {
  background-color: #3e8e41;
  border: 1px solid white;
  transform: translateY(4px);
}

</style>


<section class="bg-6 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                                <h5><b>СКАЖИ ПРИВЕТ</b></h5>
                                <h3 class="mt-30 mb-15">Contact</h3>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>



<?php
if(isset($_POST['submit'])){
if(preg_match('/^[A-Za-zА-Яа-я0-9_., ]{1,20}$/u', $_POST['name'])==true){
if(preg_match('/^[A-Za-zА-Яа-я0-9_., ]{1,100}$/u', $_POST['com'])==true){
if(isset($_SESSION['adminind'])){
$id=$_SESSION['adminind'];

$name=$_POST['name'];
$text=$_POST['com'];
$result1 = $db->query("INSERT INTO `message` ( `Название`,`Комментарий`,`id_client`) VALUES ('".$name."','".$text."','".$id."')");
echo '<meta http-equiv="refresh" content="1; URL=index.php" />';
}
else{
echo "<script>alert('Чтобы отправить своё мнение, авторизируйтесь!');</script>";
}
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>"; }}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>"; }
}
?>
 
<section class="story-area left-text center-sm-text">
        <div class="container">
                <div class="heading">
                        <img class="heading-img" src="images/heading.png" alt="">
                        <h2>Say hello</h2>
                        <h5 class="mt-10 mb-30">Поздоровайся, отправь нам комментарий о своих впечатлениях</h5>
                </div>

                <form method="post" class="was-validated">
 <div class="form-group">
    <input type="text" name="name" class="form-control" id="name" title='A-Z,a-z, ,а-я,.,_,A-Я (20 символов)' required pattern="[A-Za-zА-Яа-я0-9_., ]{1,20}"/  placeholder="Название" />
  </div>
  <div class="form-group">
     <textarea  type="text" class="h-200x ptb-20" rows="10" cols="45" name="com" title='A-Z,a-z, ,а-я,.,_,A-Я (100 символов)' required pattern="[A-Za-zА-Яа-я0-9_., ]{1,100}" id="com" placeholder="Комментарий"></textarea></div>
  <input type="submit" name="submit" class="button" /></input>
  </div>


</form> 
        </div><!-- container -->
</section>


<div class="map-area h-700x mb--30">
        <div id="map" style="height:80%;width:80%;position: relative; margin:0 auto "><script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3Aa3b635ecd88a844f668bae7b0c5ab40e02e768220078c7570a10e40ba382ed60&amp;width=auto&amp;height=700&amp;lang=ru_RU&amp;scroll=true"></script></div>

</div><!-- map-area -->
<br><br><br>
<?php
include 'footer.php';
?>

<!-- SCIPTS -->
<script src="plugin-frameworks/jquery-3.2.1.min.js"></script>
<script src="plugin-frameworks/bootstrap.min.js"></script>
<script src="plugin-frameworks/swiper.js"></script>
<script src="common/scripts.js"></script>


</body>
</html>