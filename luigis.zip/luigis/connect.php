<?php
include 'loading.php';
include 'session.php';

function get_api_catalog($db){
    $result2 = $db->query("SELECT * FROM catalog");
    $iter=1;
    $json='{ "catalog" : '.PHP_EOL;
    if ($result2->num_rows==0){
        $json.="false";
    }else{
        $json.="[ ".PHP_EOL;
        while ($row = $result2->fetch_assoc()){
            $json.='{ "Наименование" : "'.$row['Наименование'].'", '.PHP_EOL;
            $json.='"Вид" : "'.$row['Вид'].'", '.PHP_EOL;
            $json.='"Описание" : "'.$row['Описание'].'", '.PHP_EOL;
            $json.='"Цена" : "'.$row['Цена'].'" }';
            if ($result2->num_rows!=$iter){
                $iter=$iter+1;
                $json.=' , '.PHP_EOL;
            }
        }
        $json.=" ] ".PHP_EOL;
    }
    $json.=" } ".PHP_EOL;
    /*print_r ($json);
    echo (PHP_EOL);*/

    //Проверка на правильность вводимого формата JSON
    //$json=json_decode($json, false);
    //echo (PHP_EOL);
    print_r ($json);
}
function get_api_message($db){
    $result2 = $db->query("SELECT * FROM message");
    $iter=1;
    $json='{ "message" : '.PHP_EOL;
    if ($result2->num_rows==0){
        $json.="false";
    }else{
        $json.="[ ".PHP_EOL;
        while ($row = $result2->fetch_assoc()){
            $json.='{ "Название" : "'.$row['Название'].'",'.PHP_EOL;
            $json.='"Комментарий" : "'.$row['Комментарий'].'", '.PHP_EOL;
            $json.='"ФИО" : "'.$row['ФИО'].'", '.PHP_EOL;
            $json.='"id_client" : "'.$row['id_client'].'" }';
            if ($result2->num_rows!=$iter){
                $iter=$iter+1;
                $json.=' , '.PHP_EOL;
            }
        }
        $json.=" ] ".PHP_EOL;
    }
    $json.=" } ".PHP_EOL;
    /*print_r ($json);
    echo (PHP_EOL);*/

    //Проверка на правильность вводимого формата JSON
    //$json=json_decode($json, false);
    //echo (PHP_EOL);
    print_r ($json);
}
function get_api_orders($db){
    $result2 = $db->query("SELECT * FROM orders");
    $iter=1;
    $json='{ "orders" : '.PHP_EOL;
    if ($result2->num_rows==0){
        $json.="false";
    }else{
        $json.="[ ".PHP_EOL;
        while ($row = $result2->fetch_assoc()){
            $json.='{ "Номер заказа" : "'.$row['Номер заказа'].'", '.PHP_EOL;
            $json.='"Телефон клиента" : "'.$row['Телефон клиента'].'", '.PHP_EOL;
            $json.='"Адрес" : "'.$row['Адрес'].'", '.PHP_EOL;
            $json.='"ФИО" : "'.$row['ФИО'].'", '.PHP_EOL;
            $json.='"Сумма к оплате" : "'.$row['Сумма к оплате'].'", '.PHP_EOL;
            $json.='"Принято" : "'.$row['Принято'].'", '.PHP_EOL;
            $json.='"Готово" : "'.$row['Готово'].'", '.PHP_EOL;
            $json.='"Order_num" : "'.$row['order_num'].'", '.PHP_EOL;
            $json.='"id_client" : "'.$row['id_client'].'" }';
            if ($result2->num_rows!=$iter){
                $iter=$iter+1;
                $json.=' , '.PHP_EOL;
            }
        }
        $json.=" ] <br>".PHP_EOL;
    }
    $json.=" } ".PHP_EOL;
    /*print_r ($json);
    echo (PHP_EOL);*/

    //Проверка на правильность вводимого формата JSON
    //$json=json_decode($json, false);
    //echo (PHP_EOL);
    print_r ($json);
}
function get_api_posts($db){
    $result2 = $db->query("SELECT * FROM posts");
    $iter=1;
    $json='{ "posts" : '.PHP_EOL;
    if ($result2->num_rows==0){
        $json.="false";
    }else{
        $json.="[ ".PHP_EOL;
        while ($row = $result2->fetch_assoc()){
            $json.='{ "Название" : "'.$row['Название'].'", '.PHP_EOL;
            $json.='"Дата" : "'.$row['Дата'].'", '.PHP_EOL;
            $json.='"Описание" : "'.$row['Описание'].'" }';
            if ($result2->num_rows!=$iter){
                $iter=$iter+1;
                $json.=' , '.PHP_EOL;
            }
        }
        $json.=" ] ".PHP_EOL;
    }
    $json.=" } ".PHP_EOL;
    /*print_r ($json);
    echo (PHP_EOL);*/

    //Проверка на правильность вводимого формата JSON
    //$json=json_decode($json, false);
    //echo (PHP_EOL);
    print_r ($json);
}
function get_api_view($db){
    $result2 = $db->query("SELECT * FROM view");
    $iter=1;
    $json='{ "view" : '.PHP_EOL;
    if ($result2->num_rows==0){
        $json.="false";
    }else{
        $json.="[ ".PHP_EOL;
        while ($row = $result2->fetch_assoc()){
            $json.='{ "Колличество" : "'.$row['count'].'", '.PHP_EOL;
            $json.='"Вид продукции" : "'.$row['Вид'].'" }';
            if ($result2->num_rows!=$iter){
                $iter=$iter+1;
                $json.=' , '.PHP_EOL;
            }
        }
        $json.=" ] ".PHP_EOL;
    }
    $json.=" } ".PHP_EOL;
    /*print_r ($json);
    echo (PHP_EOL);*/

    //Проверка на правильность вводимого формата JSON
    //$json=json_decode($json, false);
    //echo (PHP_EOL);
    print_r ($json);
}
function get_api_help(){
echo ' 
<?php <br>
//Файл с примером обращения к API <br>
// создание нового cURL ресурса <br>
$ch = curl_init(); <br>

// установка URL и других необходимых параметров <br>
curl_setopt($ch, CURLOPT_URL, "http://n91541mu.beget.tech/index.php?api_key=""&query=catalog"); <br>
//curl_setopt($ch, CURLOPT_HEADER, $headers); <br>
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); <br>
curl_setopt($ch, CURLOPT_VERBOSE, 1); <br>
curl_setopt($ch, CURLOPT_HTTPGET, 1); <br>
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5"); <br>

// загрузка страницы и выдача её браузеру <br>
$result=curl_exec($ch); <br>
print_r($result); <br>

//Функция для проверки правильности собранного формата <br>
//False определяет что JSON будет разделен на объекты. True для массива <br>
$json=json_decode($result, false); <br>
print_r($json); <br>

// завершение сеанса и освобождение ресурсов <br>
curl_close($ch); <br>

?> <br>
//API = view <br>

{ <br>
"view" : <br>
    [ <br>
        { <br>
        "Колличество" : "589", <br>
        "Вид продукции" : "pizza" <br>
        } , <br>
        {  <br>
        "Колличество" : "608", <br>
        "Вид продукции" : "pasta" <br>
        } , <br>
        { <br>
        "Колличество" : "126", <br>
        "Вид продукции" : "salads" <br>
        } ,  <br>
        { <br>
        "Колличество" : "359", <br>
        "Вид продукции" : "seafood" <br>
        } , <br>
        { <br>
        "Колличество" : "346", <br>
        "Вид продукции" : "deserts" <br>
        } <br>
    ] <br>
} <br>

//API = orders <br>

{ <br>
"orders" : <br>
    [ <br>
        { <br>
        "Номер заказа" : "55", <br>
        "Телефон клиента" : "+79999999999", <br>
        "Адрес" : "Химки Репина 7", <br>
        "ФИО" : "", <br>
        "Сумма к оплате" : "1108.00", <br>
        "Принято" : "2022-06-05 14:39:52", <br>
        "Готово" : "", <br>
        "Order_num" : "755110382", <br>
        "id_client" : "34" <br>
        } <br>
    ] <br>
} <br>
 
<br>';}
?>