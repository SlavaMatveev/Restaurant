<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
include 'session.php';
?><head><title>IL PIACERE:Регистрация</title></head>
<?php include ("header.php");
include 'loading.php';

?>

<body>
<section class="bg-4 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                           <h3 class="mt-30 mb-15">Registration</h3>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>
<?php
$result = $db->query("SELECT * FROM accounts ");
if(isset ($_POST['submit'])){
if(preg_match('/^[A-Za-zА-Яа-я]{1,85}$/u', $_POST['f'])==true){
if(preg_match('/^[A-Za-zА-Яа-я]{1,85}$/u', $_POST['n'])==true){
if(preg_match('/^[A-Za-zА-Яа-я ]{1,85}$/u', $_POST['o'])==true){
if(preg_match('/^[+]+[7]+[0-9]{10,12}$/u', $_POST['phone'])==true){
if(preg_match('/^[^@\s]+@[^@\s]+\.[^@\s]+$/u', $_POST['login'])==true){
if(preg_match('/^[A-Za-zА-Яа-я0-9_.]{1,20}$/u', $_POST['password'])==true){
if(preg_match('/^[A-Za-zА-Яа-я0-9_.]{1,20}$/u', $_POST['password1'])==true){

  $f=$_POST['f'];
  $n=$_POST['n'];
  $o=$_POST['o'];
  $fio=$f." ".$n." ".$o;
  $ph=$_POST['phone'];
$log=$_POST['login'];
$pas=$_POST['password'];
$pas1=$_POST['password1'];


if($pas==$pas1){
if ($res=$db->query("SELECT * FROM accounts WHERE Логин LIKE '".$log."'")){
    while ($row2 = $res->fetch_assoc())
{    
    $email_confirm = $row2['email_confirm'];
}

 $row_cnt = $res->num_rows;
 $res->close();
}

  if($row_cnt > 0){
    if($email_confirm!=NULL){
    echo "<script>alert('Пользователь с таким логином уже существует!')</script>";
  echo '<meta http-equiv="refresh" content="1; URL=registration.php" />';
$db->close();
}else{
echo "<script>alert('Проверьте почту на наличие кода подтверждения, если его нет обратитесь в поддержку matveev-vo@ya.ru!')</script>";
  echo '<meta http-equiv="refresh" content="1; URL=registration.php" />';}
  }
  else{

$hash = md5($log . time());
$mail = new PHPMailer();
$mail->CharSet = 'UTF-8';
$yourEmail = 'matveev-vo@ya.ru'; // ваш email на яндексе
$password1 = 'golggrcxqtrluojf'; // ваш пароль к яндексу или пароль приложения
// настройки SMTP
$mail->Mailer = 'smtp';
$mail->Host = 'ssl://smtp.yandex.ru';
$mail->Port = 465;
$mail->SMTPAuth = true;
$mail->Username = $yourEmail; // ваш email - тот же что и в поле From:
$mail->Password = $password1; // ваш пароль;
// формируем письмо
// от кого: это поле должно быть равно вашему email иначе будет ошибка
$mail->setFrom($yourEmail, 'IL_PIACERE');
// кому - получатель письма
$mail->addAddress($log, $fio); // кому

$mail->Subject = 'Подтверждение'; // тема письма

$mail->msgHTML('
<html>
<head>
<title>Подтвердите Email</title>
</head>
<body>
<p>Что бы подтвердить Email, перейдите по <a href="http://luigis/confirmed.php?hash=' . $hash . '">ссылка</a></p>
</body>
</html>
');
if ($mail->send()) { // отправляем письмо
echo "<script>alert('Письмо с подтверждением отправлено!');</script>"; ?>
<?php

echo '<meta http-equiv="refresh" content="1; URL=index.php" />';
} else {
echo 'Ошибка: ' . $mail->ErrorInfo;
}



  $result1 = $db->query("INSERT INTO `accounts` ( `id`,`Логин`, `Пароль`,`ФИО`, `Телефон`,`pass`,`api_key`,`api_pass`,`hash`,`email_confirm`) VALUES (NULL,'$log',MD5('$pas'),'$fio','$ph','cfcd208495d565ef66e7dff9f98764da',NULL,'cfcd208495d565ef66e7dff9f98764da','$hash',NULL);");
/*$_SESSION['fio'] = $fio;
$_SESSION['login']= $log;
$_SESSION['password']= $pas;*/
  echo '<meta http-equiv="refresh" content="1; URL=index.php" />';

}
}
else{
  echo "<script>alert('Пароли не совпадают')</script>";
  echo '<meta http-equiv="refresh" content="1; URL=registration.php" />';
}
}else{
echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}else{
echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}else{
echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}else{
echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}else{
echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}else{
echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}else{
  echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";
}
}

?>  

<section class="story-area left-text center-sm-text">
        <div class="container">
                
<form method="post" style="" class="was-validated">
  <div class="form-group">
    <label for="f">Фамилия</label>
    <input type="text"name="f" class="form-control" id="f" placeholder="Введите вашу фамилию" title='A-Z,a-z,а-я,A-Я (85 символов)' required pattern="[A-Za-zА-Яа-я]{1,85}" />
  </div>
  <div class="form-group">
    <label for="n">Имя</label>
    <input type="text"name="n" class="form-control" id="n" placeholder="Введите ваше имя" title='A-Z,a-z,а-я,A-Я (85 символов)' required pattern="[A-Za-zА-Яа-я]{1,85}" />
  </div>
  <div class="form-group">
    <label for="o">Отчество</label>
    <input type="text"name="o" class="form-control" id="o" placeholder="Введите ваше отчество" title='A-Z,a-z,а-я,A-Я (85 символов)' required pattern="[A-Za-zА-Яа-я ]{1,85}" />
  </div>
  <div class="form-group">
    <label for="phone">Телефон</label>
    <input type="text"name="phone" class="form-control" id="phone" placeholder="Введите ваш телефон" title='Пример:+7**********' required pattern="[+]+[7]+[0-9]{10,12}" />
  </div>
 <div class="form-group">
    <label for="login">Логин</label>
    <input type="text"name="login" class="form-control" id="login" placeholder="Введите логин" title='Пример:primer@yandex.ru' required pattern="[^@\s]+@[^@\s]+\.[^@\s]+"/>
  </div>
  <div class="form-group">
    <label for="password">Пароль</label>
    <input type="password" name="password" class="form-control" id="password" placeholder="Введите пароль" title='A-Z,a-z,_,.,а-я,A-Я (20 символов)' required pattern="[A-Za-zА-Яа-я0-9_.]{1,20}" />
  </div>
  <div class="form-group">
    <label for="password1">Повторите пароль</label>
    <input type="password" name="password1" class="form-control" id="password1" placeholder="Повторно введите пароль" required pattern="[A-Za-zА-Яа-я0-9_.]{1,20}" />
  </div>
  <br>
  <input type="submit" name="submit" class="btn btn-primary" /></input>
</form> 
</div>
</section>

<?php include("footer.php"); ?>