<?php
include 'session.php';
include 'loading.php';
include 'security.php';
protect_page();
?>

<html>

        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
<link rel="icon" href="images/heading.ico" type="image/x-icon">
        <!-- Font -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600" rel="stylesheet">
        <link rel="stylesheet" href="fonts/beyond_the_mountains-webfont.css" type="text/css"/>

        <!-- Stylesheets -->
        <link href="plugin-frameworks/bootstrap.min.css" rel="stylesheet">
        <link href="plugin-frameworks/swiper.css" rel="stylesheet">
        <link href="fonts/ionicons.css" rel="stylesheet">
        <link href="common/styles.css" rel="stylesheet">
        <link href="drop.css" rel="stylesheet">
<style>

  a{
    text-decoration: none; 
    color:#FBCEB1
  }
  a:hover{
    text-decoration: none; 
    color:#FBCEB1
  }
  tr{
    border-top: 2px solid #321414;
  }
  th{
    border-bottom: 4px solid #321414;
  }
    .row_v2 {
        --bs-gutter-x: 1.5rem;
        --bs-gutter-y: 0;
        display: flex;
        flex-wrap: wrap;
        margin-top: calc(var(--bs-gutter-y) * -1);
        background: #FFF2D6;
      }
      .ProductCardForUpsale__counter {
        max-height: 30px;
        white-space: nowrap;
      }
      .CountSelector__control {
        border: 1px solid #321414;
        border-radius: 20%;
        background: transparent;
        color: #321414;
        cursor: pointer;
      }
      .Icon {
        fill: currentColor;
      }
      .CountSelector__input {
        width: 40px;
        margin: 0 8px;
        border: none;
        border-bottom: 1px solid #b3b3b7;
        overflow: hidden;
        text-align: center;
      }
    .container-shop-product {
      margin-top: 15px;
      margin-bottom: 15px;
      background: #FFF2D6;
    }
  </style>
  <head><title>IL PIACERE:Корзина</title></head>
<section class="bg-5 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                                <h2 class="mt-30 mb-15">Basket</h2>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>
</head>
<body onload="showMyCart()">
<section class="story-area left-text center-sm-text pos-relative">
        <div class="abs-tbl bg-2 w-20 z--1 dplay-md-none"></div>
        <div class="abs-tbr bg-3 w-20 z--1 dplay-md-none"></div>
        <div class="container">
  <div id="header-comp"></div>
<div id="in-check" class="in-check" style="color:#321414;">

    <ul class="unit">
      <li><span>Item</span></li>
      <li><span>Product Name</span></li>
      <li><span>Unit Price</span></li>
      <li><span>Delivery Detals</span></li>
      <li></li>
      <div class="clearfix"></div>
    </ul>
  </div>
        </div><!-- container -->
</section>

<footer class="pb-50  pt-70 pos-relative">
        <div class="pos-top triangle-bottom"></div>
        <div class="container-fluid">
                <a href="index.html"><img src="images/heading.png"  alt="Logo"></a><br><br>
                        <h3>IL PIACERE</h3>
                <div class="pt-30">
                        <p class="underline-secondary"><b>Адрес:</b></p>
                        <p> Москва, улица Знаменка, Здание 4 </p>
                </div>

                <div class="pt-30">
                        <p class="underline-secondary mb-10"><b>Телефон:</b></p>
                        <a href="tel:+7 915 411 42 46 ">+7 915 411 42 46 </a>
                </div>

                <div class="pt-30">
                        <p class="underline-secondary mb-10"><b>Почта:</b></p>
                        <a href="mailto:matveev-vo@ya.ru"> matveev-vo@ya.ru</a>
                </div>

                <ul class="icon mt-30">
                        <li><a href="https://www.pinterest.ru/"><i class="ion-social-pinterest"></i></a></li>
                        <li><a href="https://ru-ru.facebook.com/"><i class="ion-social-facebook"></i></a></li>
                        <li><a href="https://twitter.com/?lang=ru"><i class="ion-social-twitter"></i></a></li>
                        <li><a href="https://dribbble.com/byoutline"><i class="ion-social-dribbble-outline"></i></a></li>
                        <li><a href="https://www.youtube.com/"><i class="ion-social-youtube"></i></a></li>
                </ul>

                <p class="color-light font-9 mt-50 mt-sm-30">
Авторское право &copy;<script>document.write(new Date().getFullYear());</script> Все права защищены
</p>
        </div><!-- container -->
</footer>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
  <script src="my.js"></script>
</body>
</html>