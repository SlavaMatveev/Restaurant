<?php
include 'session.php';?>
<head><title>IL PIACERE:Авторизация</title></head>
<?php include ("header.php");
?>
</head>

<body>
<?php
include 'loading.php';


if(isset($_POST['submit'])){

if(preg_match('/^[^@\s]+@[^@\s]+\.[^@\s]+$/', $_POST['login'])==true){
  if(preg_match('/^[A-Za-zА-Яа-я0-9_.]{1,20}$/', $_POST['password'])==true){
  
$log=$_POST['login'];
$pas=MD5($_POST['password']);
$result1 = $db->query("SELECT * FROM accounts ");
$result2 = $db->query("SELECT * FROM accounts WHERE pass = MD5('1')");
$flag=false;
  
  
while ($row2 = $result2->fetch_assoc())
{
$password1=$row2['Пароль'];
$login1=$row2['Логин'];
$email_confirm=$row2['email_confirm'];
if($login1 == $log AND $password1 == $pas){
if($email_confirm!=NULL){
$_SESSION['ad_id'] = $row2['id'];
$_SESSION['fio'] = $row2['ФИО'];
$_SESSION['api_pass'] = $row2['api_pass'];
$_SESSION['api_key'] = $row2['api_key'];
}else{ 
  echo "<script>alert('Вы не подтвердили почту!');</script>";
$flag=true;
echo '<meta http-equiv="refresh" content="1; URL=admin/index.php" />';
}

$flag=true;
echo '<meta http-equiv="refresh" content="1; URL=admin/index.php" />';
exit;

  }
} 
while ($row = $result1->fetch_assoc())
{
$password=$row['Пароль'];
$login=$row['Логин'];
$email_confirm=$row['email_confirm'];

if($login == $log AND $password == $pas){
if($email_confirm!=NULL){
$_SESSION['adminind'] = $row['id'];
$_SESSION['fio'] = $row['ФИО'];
$_SESSION['login'] = $login;
$_SESSION['api_pass'] = $row['api_pass'];
$_SESSION['api_key'] = $row['api_key'];
}else{ 
  echo "<script>alert('Вы не подтвердили почту!');</script>";
$flag=true;
echo '<meta http-equiv="refresh" content="1; URL=index.php" />';
}

$flag=true;
echo '<meta http-equiv="refresh" content="1; URL=index.php" />';

} 

}
if($flag==false){
  echo "<script>alert('Неверный логин или пароль!');</script>";

  $flag=true;
}
}}else{
  echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";
}
}

function protect_page(){
        if (logged_in() === false ) {
            echo '<meta http-equiv="refresh" content="1; URL=index.php" />';
        }
    }
     function logged_in(){
        return(isset($_SESSION['ad_id'])) ? true : false;
    }

?>  

<section class="bg-6 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                                <h3 class="mt-30 mb-15">Аuthorization</h3>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>


<section class="story-area left-text center-sm-text">
        <div class="container">
               <form method="post" class="was-validated">
 <div class="form-group">
    <label for="login">Логин</label>
    <input type="text"name="login" class="form-control" title='Пример:primer@yandex.ru)' id="login" required pattern="[^@\s]+@[^@\s]+\.[^@\s]+"/  placeholder="Введите логин" />

  </div>
  <div class="form-group">
    <label for="password">Пароль</label>
    <input type="password" name="password" class="form-control" title='A-Z,a-z, ,а-я,.,_,A-Я (20 символов)' id="password" required pattern="[A-Za-zА-Яа-я0-9_.]{1,20}" placeholder="Пароль"/>
  </div>
  <input type="submit" name="submit" class="btn btn-primary" /></input>
</form> 
        </div><!-- container -->
</section>




</body>

<?php 
include('footer.php');
?>
