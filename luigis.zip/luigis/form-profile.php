<?php
include 'session.php';
include 'security.php';
protect_page();?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<head><title>IL PIACERE:Изменение</title></head>
<?php include ("header.php");
include 'loading.php';
?>

<body>
  <link href="profile.css" rel="stylesheet">
<section class="bg-4 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                           <h3 class="mt-30 mb-15">My profile</h3>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>
<section class="story-area left-text center-sm-text">
        <div class="container">
          <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <?php

 $id=$_SESSION['adminind'];


$result=$db->query("SELECT * FROM `accounts` WHERE `id` LIKE '$id'");
while ($row = $result->fetch_assoc())
{
?>
<div class="card">
  <h3><?php echo $row['ФИО'];?></h3>
  <h4>Телефон:</h4><p><h5 style="color:red;"><?php echo $row['Телефон'];?></h5></p>
  <h4>Логин:</h4><p><h5 style="color:red;"><?php echo $row['Логин'];?></h5></p>
   </table><br>
  <p><button><a href="myprofile.php">Изменить</a></button></p>
  <!--<p><button><a href="form-profile.php?do=<?php /*echo $row['id'];*/?>" >Удалить</a></button></p>-->
<?php

$ps1=md5(1);
$ps2=md5(2); if($_SESSION['api_pass']==$ps1 || $_SESSION['api_pass']==$ps2 ){ ?><p><button><a href="api.php" role="button">Оформление заявки</a></button></p><?php }else{ ?><p><button><a  role="button">Для доступа к оформлению заявки обратитесь в службу поддержки</a></button></p><?php }?>

</div>

<?php
}


if(isset($_GET['do'])){
 $id=$_GET['do'];
  $db->query("DELETE FROM `accounts` WHERE `id` LIKE '$id'");

echo "<script>window.location.href='logout.php'</script>";
}



?>

    




        </div><!-- container -->
</section>


<?php
include("footer.php"); ?>