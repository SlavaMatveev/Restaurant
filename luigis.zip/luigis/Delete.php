<?php 
session_start();
unset($_SESSION['cart']);
unset($_SESSION['arr']);
?>
<script>
window.history.back();
</script>