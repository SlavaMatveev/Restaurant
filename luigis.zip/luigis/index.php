<?php
session_start();
include 'loading.php';
include 'connect.php';
if(isset ($_SESSION['fio'])){$user=$_SESSION['fio'];}
if(isset ($_SESSION['password'])){
if(isset ($_SESSION['login'])){     
$pas=$_SESSION['password'];
$log=$_SESSION['login'];}}


if(isset ($user) && isset($pas) && isset($log)){
$result2=$db->query("SELECT * FROM accounts WHERE Пароль LIKE MD5('$pas') AND Логин LIKE '$log'");
while ($row = $result2->fetch_assoc())
{
$_SESSION['adminind'] = $row['id'];
}
}
$ps1=md5(1);
$ps2=md5(2);


if (!isset($_GET["query"]) || !isset($_GET["api_key"])){

include 'header.php';
?>

<head><title>IL PIACERE:Главная</title></head>
<section class="bg-1 h-900x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white">
                                <h5><b>ЛУЧШИЙ В ГОРОДЕ</b></h5>
                                <h1 class="mt-30 mb-15">Pizza & Pasta</h1>
                                <h5><a href="03_menu.php" class="btn-primaryc plr-25"><b>ПОСМОТРЕТЬ СЕГОДНЯШНЕЕ МЕНЮ</b></a></h5>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>


<section class="story-area left-text center-sm-text pos-relative">
        <div class="abs-tbl bg-2 w-20 z--1 dplay-md-none"></div>
        <div class="abs-tbr bg-3 w-20 z--1 dplay-md-none"></div>
        <div class="container">
                <div class="heading">
                        <img class="heading-img" src="images/heading.png" alt="">
                        <h2>Our Story</h2>
                </div>

                <div class="row">
                        <div class="col-md-3">
                </div>
                        <div class="col-md-6" >
                                <p class="mb-30" style="text-align: center" >В шумном городе так важно найти место по душе, где можно собираться всей семьей, наслаждаться высокой кухней и отдыхать вместе с детьми. В далеком 1999 году группа единомышленников задумала грандиозный проект открытия нового направления в ресторанном бизнесе. В конце 90-х годов итальянские рестораны в Москве были в диковинку, а чувство вкуса у потребителей было недостаточно развито.
 Так родилась мысль создать место, где красота, вкус и качество блюд переплетаются воедино. В результате появился ресторан и кондитерская IL PIACERE. Трехэтажное строение  с банкетным залом, террасой и верандой с первого дня начало привлекать гостей.</p>
                        </div><!-- col-md-6 -->
<div class="col-md-3">
                </div>
                        
                </div><!-- row -->
        </div><!-- container -->
</section>



<section class="story-area bg-seller color-white pos-relative" style="margin:0 auto;
background-image:url(images/slider_5_1920_600.jpg);
background-repeat:no-repeat;
background-attachment:fixed;">
        <div class="pos-bottom triangle-up"></div>
        <div class="pos-top triangle-bottom"></div>
        <div class="container">
                <div class="heading">
                        <img class="heading-img"  src="images/heading.png" alt="">
                        <h2>Sellers</h2>
                </div>
                <div class="row" >
                        <div class="col-sm-12" >
                                <ul class="selecton brdr-b-primary mb-70" >
                                        <li><a class="active" href="#" data-select="*"><b>ВСЕ</b></a></li>
                                        <li><a href="#" data-select="1"><b>ПИЦЦА</b></a></li>
                                        <li><a href="#" data-select="2"><b>ПАСТА</b></a></li>
                                        <li><a href="#" data-select="3"><b>САЛАТЫ</b></a></li>
                                        <li><a href="#" data-select="4"><b>ДЕСЕРТЫ</b></a></li>
                                        <li><a href="#" data-select="5"><b>МОРЕПРОДУКТЫ</b></a></li>
                                </ul>
                        </div><!--col-sm-12-->
                </div><!--row-->

<?php

$result2 = $db->query("SELECT * FROM catalog");
?>
<div class="row">
<?php while ($row = $result2->fetch_assoc())
{ 
?>
                        <div class="col-md-6 food-menu <?php echo $row['Вид'];?>" >
                                <div class="sided-90x mb-30 ">
                                        <div class="s-left"><img class="br-3" src="<?php echo $row['Изображение']; ?>" alt="Menu Image"></div><!--s-left-->
                                        <div class="s-right">
                                                <h6 class="mb-10"><b><?php echo $row['Наименование']; ?></b><b class="color-primary plr-25"><?php echo $row['Цена']; ?> р.</b><a href="03_menu.php#<?php echo $row['id'];?>" class="btn-brdr-primary float-right"><b>Перейти</b></a></h6>
                                        </div><!--s-right-->
                                </div><!-- sided-90x -->
                        </div><!-- food-menu -->
<?php 
} 
?>
                       
                </div><!-- row -->

                <h6 class="center-text mt-40 mt-sm-20 mb-30"><a href="03_menu.php" class="btn-primaryc plr-25"><b>СМОТРЕТЬ СЕГОДНЯШНЕЕ МЕНЮ</b></a></h6>
        </div><!-- container -->
</section>
<br><br><br><br>
<?php
include 'footer.php';
?>

<!-- SCIPTS -->
<script src="plugin-frameworks/jquery-3.2.1.min.js"></script>
<script src="plugin-frameworks/bootstrap.min.js"></script>
<script src="plugin-frameworks/swiper.js"></script>
<script src="common/scripts.js"></script>

</body>
</html>
<?php  

}else { 
$key_key=$_GET["api_key"];
$result3=$db->query("SELECT * FROM accounts WHERE api_key LIKE '$key_key'");
while ($row5 = $result3->fetch_assoc())
{
$key=$row5['api_key'];
$passs=$row5['api_pass'];
}
if(!isset($key)){
    $key = '';
}
if(!isset($passs)){
    $passs = '';
}

if($_GET["api_key"]==$key ){

if ($_GET["query"]=="help"){

if($passs==$ps1 || $passs==$ps2 ){

        get_api_help(); }else{ echo "<script>alert('У вас нет доступа!');</script>";
echo '<meta http-equiv="refresh" content="1; URL=index.php" />';}

}
else if ($_GET["query"]=="catalog"){

if($passs==$ps1 || $passs==$ps2 ){

        get_api_catalog($db); }else{ echo "<script>alert('У вас нет доступа!');</script>";
echo '<meta http-equiv="refresh" content="1; URL=index.php" />';}

}else if ($_GET["query"]=="message"){

if($passs==$ps2){

        get_api_message($db); }else{ echo "<script>alert('У вас нет доступа!');</script>";
echo '<meta http-equiv="refresh" content="1; URL=index.php" />';}

}else if ($_GET["query"]=="orders"){

if($passs==$ps2){

        get_api_orders($db); }else{ echo "<script>alert('У вас нет доступа!');</script>";
echo '<meta http-equiv="refresh" content="1; URL=index.php" />';}

}else if ($_GET["query"]=="posts"){

if($passs==$ps2){

        get_api_posts($db); }else{ echo "<script>alert('У вас нет доступа!');</script>";
echo '<meta http-equiv="refresh" content="1; URL=index.php" />';}

}else if ($_GET["query"]=="view"){

if($passs==$ps1 || $passs==$ps2 ){

        get_api_view($db); }else{ echo "<script>alert('У вас нет доступа!');</script>";
echo '<meta http-equiv="refresh" content="1; URL=index.php" />';}
}
}else{ echo "<script>alert('Ваш api ключ не правильный!');</script>";
echo '<meta http-equiv="refresh" content="1; URL=index.php" />';

}}


?>