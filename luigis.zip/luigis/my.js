function showHeader() {
$.ajax({
async: false,
type: "POST",
url: 'header.php',
dataType: "text",
data: 'action=show',
error: function() {
alert("Произошла ошибка при добавлении товара");
},
success: function (response) {
$('#header-comp').html(response);
}
});
}


function addToCart(id) {
console.log('add'+id);
$.ajax({
async: false,
type: "POST",
url: 'Функционал корзины.php',
dataType: "text",
data: 'action=add&id='+id,
error: function() {
alert("Ошибка при добавлении!");
},
success: function (response) {
showMyCart();
showHeader();
}
});
}

function showMyCart() {
console.log('show ');
$.ajax({
async: false,
type: "POST",
url: 'Функционал корзины.php',
dataType: "text",
data: 'action=show',
error: function() {
alert("Произошла ошибка при добавлении товара");
},
success: function (response) {
showHeader();
$('#in-check').html(response);
}
});
}

function delFromCart(id) {
console.log('del'+id);
$.ajax({
async: false,
type: "POST",
url: 'Функционал корзины.php',
dataType: "text",
data: 'action=del&id='+id,
error: function() {
alert("Произошла ошибка при удалении товара");
},
success: function (response) {
showMyCart();
alert("Удалить товар из корзины?")
console.log(response);
}
});
}

function delFromOne(id) {
console.log('delOne'+id);
$.ajax({
async: false,
type: "POST",
url: 'Функционал корзины.php',
dataType: "text",
data: 'action=delOne&id='+id,
error: function() {
alert("Произошла ошибка при удалении товара");
},
success: function (response) {
showMyCart();
console.log(response);
}
});
}

function addToOne(id) {
console.log('addOne'+id);
$.ajax({
async: false,
type: "POST",
url: 'Функционал корзины.php',
dataType: "text",
data: 'action=addOne&id='+id,
error: function() {
alert("Ошибка при добавлении!");
},
success: function (response) {
showMyCart();
console.log(response);
}
});
}

$("#PlusOneProduct").click(delFromOne);
$("#DelOneProduct").click(addToOne);