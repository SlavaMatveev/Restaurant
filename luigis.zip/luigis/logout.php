<?php session_start();


 unset($_SESSION['fio']);
 
 session_destroy();
 header("Location: index.php");
?>