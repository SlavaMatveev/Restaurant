<?php
session_start();
include 'security.php';
protect_page();
?> 
<!DOCTYPE html>
<html lang="en">
<?php

include 'head.php';
include 'header.php';
?>
<div class="container-joj" style="">
  <div class="" style="  width: 32%; margin: 0 auto; text-align: center; border-top: none; heigh: 30px;">
    <div class="blockquote" style=" color:007bff; font-size:35px; margin:0px; left: 50%; text-align: center;">ДОЛЖНОСТИ</div>
  </div>
</div>
</div>
<style>
  table, th, td {
        border: 1px solid black;
    }

</style>
<body>
	<br>
	<a class="btn btn-primary" data-bs-toggle="modal" href="#exampleModalToggle" role="button" style="position: relative;left: 50%;transform: translate(-130%, 0);">Удалить</a>
	<a class="btn btn-primary" data-bs-toggle="modal" href="#exampleModalToggle2" role="button" style="position: relative;left: 50%;transform: translate(-100%, 0);">Добавить</a>
	  <a class ="btn btn-primary" href="p_position.php"> Распечатать</a>
  <form method="POST">
  <div class="dropdown"><br>
  <button class="btn btn-secondary dropdown-toggle" style="position: relative;left: 50%;transform: translate(-60%, 0);" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Фильтры и Сортировка
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <input type="submit" name="exampleModalToggle3" value="Все данные базы по ID" /><br>
<input type="submit" name="exampleModalToggle4" value="Сортировка по колличеству" /><br>

  </div>
</div>

</form>
<br><br>
<table border="1" width="600" align="center">
<tr>
<th>ID</th> 
<th>Название должности</th> 
<th>Зарплата</th> 
<th>Обязанности</th> 
<th>Требования</th> 	
<th>Колличество сотрудников</th>   
</tr>

<?php
$db = mysqli_connect('localhost', 'root', 'root', 'restaurant');
$sql = "SELECT * FROM position";
$result1 = $db->query($sql);
if( isset( $_POST['exampleModalToggle3'] ) )
{
$sql = "SELECT * FROM position";
$result1 = $db->query($sql);
}
if( isset( $_POST['exampleModalToggle4'] ) )
{
  $sql = "SELECT * FROM position  ORDER BY count ASC";
$result1 = $db->query($sql);
}
while ($row = $result1->fetch_assoc())
{
echo "<tr>\n<td>".$row["id"]."</td>"."\n"."<td>"."".$row["name"]."
</td>"."\n"."<td>"."".$row["salary"]."</td>"."\n"."<td>"."".$row
["responsibility"]."</td>"."\n"."<td>"."".$row["requirement"]."</td>"."\n"."<td>"."".$row["count"]."</td>"."\n"."<td>".""."<a href='edit_position.php?id1=".$row["id"]."' class='btn btn-primary'>Изменить</a>"."</td>";
}
?>
</table>

<div class="modal fade" id="exampleModalToggle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1" >
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="exampleModalToggleLabel">Удалить</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form method="POST" name="form">
<select name="name" class="form-select">
<?php
$res = $db->query("SELECT * FROM `position`");
while($row=$res->fetch_assoc()) {
echo "<option value='".$row["id"]."'>".$row["id"]." ".$row["name"]."</option>";
}
?>

</select>
<br>
<input class="btn btn-primary" name="del" type="submit" value="Удалить">
</form>
</div>
</div>
</div>
</div>
<?php
if( isset( $_POST['del'])){
$name=$_POST['name'];
$db->query("DELETE FROM `position` WHERE `id` LIKE '".$name."'");
echo "<script>
window.location.href='position.php'</script>";
}
?>





<div class="modal fade" id="exampleModalToggle2" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="exampleModalToggleLabel2">Добавление</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form method="POST" name="form" >

<div class="form-group">

   <input name="name" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Название должности"><br>
  <input name="salary" type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Зарплата"><br>
    <input name="responsibility" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Обязанности"><br>
  <input name="requirement" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Требования"><br>
  </div>
<br>
<input class="btn btn-primary" name="do" type="submit" href="#" >
</form>
</div>
</div>
</div>
</div>
<?php
if(isset($_POST['do'])){
$name=$_POST['name'];
$salary=$_POST['salary'];
$responsibility=$_POST['responsibility'];
$requirement=$_POST['requirement'];
$db->query("INSERT INTO `position` (`name`, `salary`, `responsibility`, `requirement`) VALUES('$name', '$salary','$responsibility','$requirement')");

echo "<script>
window.location.href='position.php'</script>";

    }
    ?>





</body>
</html>