<footer class="pb-50  pt-70 pos-relative">
        <div class="pos-top triangle-bottom"></div>
        <div class="container-fluid">
                <a href="index.html"><img src="../images/heading.png"  alt="Logo"></a><br><br>
                        <h3>IL PIACERE</h3>


                <p class="color-light font-9 mt-50 mt-sm-30">
Авторское право &copy;<script>document.write(new Date().getFullYear());</script> Все права защищены
</p>
        </div><!-- container -->
</footer>
<div id="preloader_malc">

<div>

                <img src="../images/6O4X.gif">

        </div>
</div>

<style type="text/css">
        #preloader_malc {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0, 0, 0, 0.6);
                z-index: 99
        }

        #preloader_malc div {
                background: #0000.6;
                width: 260px;
                height: 40px;
                line-height: 30px;
                border-radius: 0px;
                border-color: #ffee00;
                font-family: arial;
                font-size: 15px;
                color: #ffee00;
                text-align: center;
                
                position: fixed;
                z-index: 999;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                margin: auto
        }
</style>

<script type="text/javascript">

        window.onload = function() {

                setTimeout(function() {

                        document.getElementById("preloader_malc").style.display = "none";


                }, 400);

        };

</script>