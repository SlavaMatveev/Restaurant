<?php
include 'session.php';

include 'security.php';
protect_page();
?> 
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?php

include 'head.php';

?><head>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.4.1/jspdf.min.js"></script>
<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script></head>
<div class="container-joj" style="">
  <div class="" style="  width: 32%; margin: 0 auto; text-align: center; border-top: none; heigh: 30px;">
    <div class="blockquote" style=" color:007bff; font-size:35px; margin:0px; left: 50%; text-align: center;">VIEW</div>
  </div>
</div>
</div>
<style>
  table, th, td {
        border: 1px solid black;
    }

</style>
<body>
	<input type="button" onclick="history.back();" value="Назад"/>
<input type="button" value="Распечатать" onclick="PrintElem('#print')" />
<div id="print">
<table border="1" width="600" align="center">
<tr>

<th>ID</th> 
<th>Колличество</th>
<th>Вид</th> 

</tr>

<?php
include 'loading.php';
?>
<?php
$sql = "SELECT * FROM view";
$result1 = $db->query($sql);

while ($row = $result1->fetch_assoc())
{
echo "<tr>\n<td>".$row["id"]."</td>"."\n"."<td>"."".$row["count"]."
</td>"."\n"."<td>"."".$row["Вид"]."</td>";
}
?>

</table>
</div>
<script type="text/javascript">
function PrintElem(elem)
{
Popup($(elem).html());
}
function Popup(data)
{
var mywindow = window.open('', 'my div', 'height=400,width=600');
mywindow.document.write('<html><head><title>my div</title>');
mywindow.document.write('</head><body >');
mywindow.document.write(data);
mywindow.document.write('</body></html>');
mywindow.document.close(); 
mywindow.focus(); 
mywindow.print();
mywindow.close();
return true;
}
</script>



</body>
</html>