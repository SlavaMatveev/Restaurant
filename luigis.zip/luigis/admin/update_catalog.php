<?php
include 'session.php';
include 'loading.php';
include 'security.php';
protect_page();
?>


    <?php 
$uploaddir = '../images/catalog/';
$apend=date('YmdHis').rand(100,1000).'.jpg'; 
$uploadfile = "$uploaddir$apend"; 
if(($_FILES['userfile']['type'] == 'image/gif' || $_FILES['userfile']['type'] == 'image/jpeg' || $_FILES['userfile']['type'] == 'image/png') && ($_FILES['userfile']['size'] != 0)) 
{ 
  if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile))  
   { 

   }
}
   else{
       $apend="";
   } 
if(isset($_POST['do'])){
 $id=$_GET['id'];
 echo "<script>alert('$id');</script>";
if(preg_match('/^\d+(\.\d{2})?$/u', $_POST['Цена'])==true){
if(preg_match('/^[A-Za-zА-Яа-я1-9 ]{1,85}$/u', $_POST['Наименование'])==true){
if(preg_match('/^[A-Za-zА-Яа-я1-9., \-]{1,1000}$/u', $_POST['Описание'])==true){
$vid=$_POST['vid'];
 $cena=$_POST['Цена'];
 $nam=$_POST['Наименование'];
 $opis=$_POST['Описание'];
 $imag="images/catalog/".$apend;

if($imag=="images/catalog/"){
	
   $db->query("UPDATE `catalog` SET `Наименование`='$nam',`Описание`='$opis',`Цена`='$cena',`Вид`='$vid' WHERE `id` LIKE '$id'");
echo "<script>
window.location.href='catalog.php'</script>";
    }
    else{
    	$res = $db->query("SELECT * FROM `catalog` WHERE `id` LIKE '".$id."' ");
while($row=$res->fetch_assoc()) {
$iso=$row["Изображение"];
}
unlink("../".$iso);
$db->query("UPDATE `catalog` SET `Наименование`='$nam',`Описание`='$opis',`Цена`='$cena',`Вид`='$vid',`Изображение`='$imag' WHERE `id` LIKE '$id'");
echo "<script>
window.location.href='catalog.php'</script>";
}
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!1');</script>";}
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!2');</script>";}
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!3');</script>";}
}
 ?>
