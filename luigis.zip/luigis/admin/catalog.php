<?php
include 'session.php';
include 'security.php';
protect_page();
?> 
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"><head><title>IL PIACERE:CATALOG</title></head>
<?php

include 'head.php';
include 'header.php';
?>

<?php
include 'loading.php';
?>
<style>

  table {
  width: 100%;
  margin-bottom: 20px;
  border: 5px solid #fff;
  border-top: 5px solid #fff;
  border-bottom: 3px solid #fff;
  border-collapse: collapse; 
  outline: 3px solid #EF0031;
  font-size: 15px;
  background: #fff!important;
}
 th {
  font-weight: bold;
  padding: 7px;
  background: #EF0031;
  border: none;
  text-align: left;
  font-size: 15px;
  border-top: 3px solid #fff;
  border-bottom: 3px solid #EF0031;
  color:white!important;
}
 td {
  padding: 7px;
  border: none;
  border-top: 3px solid #fff;
  border-bottom: 3px solid #fff;
  font-size: 15px;

}
ul{text-align:center;}
ul li{display:inline-block;}
</style>
<body >
  <section class="bg-4 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                                <h5><b>ЛУЧШИЙ В ГОРОДЕ</b></h5>
                                <h2 class="mt-30 mb-15">CATALOG</h2>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>
<br><br>
                <ul class="main-menu font-mountainsre" >

                        <li><a class="btn btn-primary" data-bs-toggle="modal" href="#exampleModalToggle2" role="button">Добавить</a></li>
                <li><a class ="btn btn-primary" href="p_catalog.php"> Распечатать</a></li>
                <li><form method="POST"><div class="dropdown" >
  <button class="btn btn-secondary dropdown-toggle"  type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Фильтры и Сортировка
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <input type="submit" name="exampleModalToggle3" value="Все данные базы по ID" /><br>
<input type="submit" name="exampleModalToggle6" value="Сортировка по убыванию ID"/><br>


  </div>
</div></form></li>

                    <li><form class="d-flex" method="POST" action="catalog.php">
        <input class="form-control me-2" type="search" placeholder="Поиск" name="search" aria-label="Search">
        <input class="btn btn-primary" type="submit" name='submit' value='Найти'>
      </form></li>
      <li><form class="d-flex" method="POST" action="catalog.php">
        <input class="btn btn-primary" type="submit" name="back" value="Отменить поиск">
    </form></li>
                </ul>



<br><br>
<table border="1" width="600" align="center">
<tr >

<th>ID</th> 
<th>Наименование</th>
<th>Вид</th> 
<th>Описание</th> 
<th>Изображение</th> 
<th>Цена</th> 
</tr>



<?php
if(isset($_POST['submit'])){ 

$s=$_POST['search'];
$sql = ("SELECT * FROM `catalog` WHERE `id` LIKE '%$s%' OR `Наименование` LIKE '%$s%' OR `Вид` LIKE '%$s%' OR `Описание` LIKE '%$s%' OR `Цена` LIKE '%$s%' ");
$result1 = $db->query($sql);
}
else if(isset($_POST['back'])){ 
  $sql = ("SELECT * FROM `catalog`");
$result1 = $db->query($sql);
}
  
else if( isset( $_POST['exampleModalToggle3'] ) )
{
$sql = "SELECT * FROM catalog";
$result1 = $db->query($sql);
}



else if( isset( $_POST['exampleModalToggle6'] ) )
{
$sql = "SELECT * FROM catalog ORDER BY id DESC";
$result1 = $db->query($sql);
}

else if( isset( $_POST['exampleModalToggle7'] ) )
{
$vid=$_POST['exampleModalToggle7'];
$sql = "SELECT * FROM catalog WHERE Вид='$vid'";
$result1 = $db->query($sql);
}
else {
    $sql = ("SELECT * FROM `catalog`");
$result1 = $db->query($sql);
}
while ($row = $result1->fetch_assoc())
{
  
echo "<tr>\n<td>".$row["id"]."</td>"."\n"
."<td>"."".$row["Наименование"]."</td>"."\n"
."<td>"."".$row["Вид"]."</td>"."\n"
."<td>"."".$row["Описание"]."</td>"."\n"
."<td><img src='../".$row["Изображение"]."' ></td>"."\n"
."<td>"."".$row["Цена"]."</td>"."\n"
."<td>".""."<a href='edit_catalog.php?id1=".$row["id"]."' class='btn btn-primary'>Изменить</a>"."</td>"."\n"
."<td>".""."<a href='catalog.php?id2=".$row["id"]."' class='btn btn-primary'>Удалить</a>"."</td>";
}

?>

</table>
<br>
<?php    include 'footer.php'; 
if (isset($_GET['id2'])) {
    $id = $_GET['id2'];

$res = $db->query("SELECT * FROM `catalog` WHERE `id` LIKE '".$id."' ");
while($row=$res->fetch_assoc()) {
$iso=$row["Изображение"];
}
unlink("../".$iso);
    $db->query("DELETE FROM `catalog` WHERE `id` LIKE '$id'");
    echo "<script>
window.location.href='catalog.php'</script>";
}
?>

<div class="modal fade" id="exampleModalToggle2" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="exampleModalToggleLabel2">Добавление</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form method="POST" class="was-validated" ENCTYPE="multipart/form-data">

<div class="form-group" >
 <label for="vid"> Вид:</label>
                      <select class="form-select" id="exampleInputEmail1" name="vid" >
                        <?php
                        $result = $db->query("SELECT * FROM view");
                        while($row2=$result->fetch_assoc()) {?>
                            <option value="<?php echo $row2['id']?>"><?php echo $row2['Вид']?></option>
                        <?php }
                        ?>
                    </select><br>
                    <label > Изображение:</label>
 <input name="userfile" type="file" multiple accept="image/*"  class="form-control" ><br>
 <label > Цена:</label>
  <input name="Цена" type="text" class="form-control" title='Пример:100.00'id="exampleInputEmail2"  required pattern="\d+(\.\d{2})?" placeholder="Цена"><br>
  <label > Наименование:</label>
  <input name="Наименование" type="text" class="form-control" title='A-Z,a-z,A-Я, ,а-я,(85 символов)' id="exampleInputEmail3"  required pattern="[A-Za-zА-Яа-я1-9 ]{1,85}" placeholder="Наименование"><br>
  <label > Описание:</label>
  <input name="Описание" type="text" class="form-control" id="exampleInputEmail4" title=',,A-Z,a-z,A-Я, ,а-я (1000 символов)' required pattern="[A-Za-zА-Яа-я1-9., ]{1,1000}" placeholder="Описание"><br>
  
  <br>
  </div>
<br>
<input class="btn btn-primary" name="do" type="submit" href="#" >
</form>
</div>
</div>
</div>
</div>

<?php 
$uploaddir = '../images/catalog/';
$apend=date('YmdHis').rand(100,1000).'.jpg'; 
$uploadfile = "$uploaddir$apend"; 
if(($_FILES['userfile']['type'] == 'image/gif' || $_FILES['userfile']['type'] == 'image/jpeg' || $_FILES['userfile']['type'] == 'image/png') && ($_FILES['userfile']['size'] != 0)) 
{ 
  if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile))  
   { 

   }
}
else{
       $apend="";
   } 
if(isset($_POST['do'])){
if(preg_match('/^\d+(\.\d{2})?$/u', $_POST['Цена'])==true){
if(preg_match('/^[A-Za-zА-Яа-я1-9 ]{1,85}$/u', $_POST['Наименование'])==true){
if(preg_match('/^[A-Za-zА-Яа-я1-9., \-]{1,1000}$/u', $_POST['Описание'])==true){
$vid=$_POST['vid'];
$cena=$_POST['Цена'];
$nam=$_POST['Наименование'];
$opis=$_POST['Описание'];
$imag="images/catalog/".$apend;


   $db->query("INSERT INTO `catalog` (`id`, `Наименование`, `Вид`, `Описание`, `Изображение`, `Цена`) VALUES(NULL, '$nam','$vid','$opis','$imag','$cena')");
echo "<script>
window.location.href='catalog.php'</script>";
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}
 ?>



</body>
</html>