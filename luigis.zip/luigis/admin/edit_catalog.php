<?php
include 'session.php';
include 'loading.php';
include 'security.php';
protect_page();
$id=$_GET["id1"];
?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"><head><title>IL PIACERE:CATALOG:Изменение</title></head>
<?php

include 'head.php';
include 'header.php';
?>

<section class="bg-4 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                                <h5><b>ЛУЧШИЙ В ГОРОДЕ</b></h5>
                                <h2 class="mt-30 mb-15" id="exampleModalToggleLabel2">CATALOG:Изменение</h2>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>

<?php
echo "<form method='POST' class='was-validated' ENCTYPE='multipart/form-data' action='update_catalog.php?id=$id'>";
$row = $db->query("SELECT * FROM catalog WHERE id='$id'");
$row = $row->fetch_assoc();
?>
<div class="form-group"><br>
 <label for="vid"> Вид:</label>
                      <select class="form-select" id="exampleInputEmail1" name="vid" required>
                        <?php
                        $result = $db->query("SELECT * FROM view");
                        while($row2=$result->fetch_assoc()) {?>
                            <option value="<?php echo $row2['id']?>"><?php echo $row2['Вид']?></option>
                        <?php }
                        ?>
                    </select><br>

 <input name="userfile" type="file" multiple accept="image/*"  class="form-control" ><br>
 <?php
 echo "<label > Цена:</label>";
 echo "<input name='Цена' type='text' value='".$row["Цена"]."' class='form-control' id='exampleInputEmail2' title='Пример: 100,00' required pattern='\d+(\.\d{2})?' placeholder='Цена'><br>";
   echo "<label > Наименование:</label>";
   echo "<input name='Наименование' value='".$row["Наименование"]."' type='text' class='form-control' title='A-Z,a-z,A-Я, ,а-я (85 символов)' id='exampleInputEmail3'  required pattern='[A-Za-zА-Яа-я1-9 ]{1,85}' placeholder='Наименование'<br><br>";
   echo "<label > Описание:</label>";
   echo "<input name='Описание' type='text' value='".$row["Описание"]."' class='form-control' id='exampleInputEmail4' title=',,A-Z,a-z,A-Я, ,а-я- (1000 символов)' required pattern='[A-Za-zА-Яа-я1-9., \-]{1,1000}' placeholder='Описание'><br>";
?>

  </div>
<br>
<input class="btn btn-primary" style="position: relative;left: 50%;transform: translate(-50%, 0);" name="do" type="submit"  >
<br><br>
<?php include 'footer.php'; ?>
</form>



