<?php
include 'session.php';
include 'loading.php';
include 'security.php';
protect_page();
?>


    <?php 
$uploaddir = '../images/posts/';
$apend=date('YmdHis').rand(100,1000).'.jpg'; 
$uploadfile = "$uploaddir$apend"; 
if(($_FILES['userfile']['type'] == 'image/gif' || $_FILES['userfile']['type'] == 'image/jpeg' || $_FILES['userfile']['type'] == 'image/png') && ($_FILES['userfile']['size'] != 0)) 
{ 
  if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile))  
   { 

   }
}
   else{
       $apend="";
   } 
if(isset($_POST['do'])){
$id=explode("=",$_SERVER["QUERY_STRING"])[1];
if(preg_match('/^[A-Za-zА-Яа-я0-9_., ]{1,300}$/u', $_POST['name'])==true){
  if(preg_match('/^[A-Za-zА-Яа-я0-9_., ]{1,300}$/u', $_POST['tex'])==true){
$na=$_POST['name'];
$te=$_POST['tex'];
$ad_id=$_SESSION['ad_id'];
$imag="images/posts/".$apend;

if($imag=="images/posts/"){
	
   $db->query("UPDATE `posts` SET Название='$na',Описание='$te' WHERE id='$id'");
echo "<script>
window.location.href='posts.php'</script>";
    }
    else{
    	$res = $db->query("SELECT * FROM `posts` WHERE `id` LIKE '".$id."' ");
while($row=$res->fetch_assoc()) {
$iso=$row["Изображение"];
}
unlink("../".$iso);
$db->query("UPDATE `posts` SET Название='$na',Описание='$te',Изображение='$imag',id_admin='$ad_id' WHERE id='$id'");
echo "<script>
window.location.href='posts.php'</script>";
}
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}
 ?>
