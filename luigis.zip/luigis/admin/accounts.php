<?php
include 'session.php';
include 'security.php';
protect_page();
?> 
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<head><title>IL PIACERE:ACCOUNTS</title></head>
<?php
include 'head.php';
include 'header.php';
?>

<style>

  table {
  width: 100%;
  margin-bottom: 20px;
  border: 5px solid #fff;
  border-top: 5px solid #fff;
  border-bottom: 3px solid #fff;
  border-collapse: collapse; 
  outline: 3px solid #EF0031;
  font-size: 12px;
  background: #fff!important;
}
 th {
  font-weight: bold;
  padding: 7px;
  background: #EF0031;
  border: none;
  text-align: left;
  font-size: 12px;
  border-top: 3px solid #fff;
  border-bottom: 3px solid #EF0031;
  color:white!important;
}
 td {
  padding: 7px;
  border: none;
  border-top: 3px solid #fff;
  border-bottom: 3px solid #fff;
  font-size: 10px;

}
ul{text-align:center;}
ul li{display:inline-block;}

</style>
<body >
  <section class="bg-4 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                                <h5><b>ЛУЧШИЙ В ГОРОДЕ</b></h5>
                                <h2 class="mt-30 mb-15">ACCOUNTS</h2>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>
<br><br>
                <ul class="main-menu font-mountainsre" >

                  <li><a class="btn btn-primary" data-bs-toggle="modal" href="#exampleModalToggle2" role="button">Добавить</a></li>
                  <li><a class ="btn btn-primary" href="p_accounts.php"> Распечатать</a></li>
                  <li>
                    <form method="POST">
                    <div class="dropdown" >
                      <button class="btn btn-secondary dropdown-toggle"  type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Фильтры и Сортировка</button>
                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <input type="submit" name="exampleModalToggle3" value="Все данные базы по ID" /><br>
                        <input type="submit" name="exampleModalToggle4" value="Сортировка по ФИО" /><br>
                        <input type="submit" name="exampleModalToggle5" value="Сортировка по Логину" /><br>
                        <input type="submit" name="exampleModalToggle6" value="Фильтр 'Администраторы'"/><br>
                        <input type="submit" name="exampleModalToggle7" value="Фильтр 'Пользователи'"/><br>
                        <input type="submit" name="exampleModalToggle8" value="Фильтр 'API-2'"/><br>
                        <input type="submit" name="exampleModalToggle9" value="Фильтр 'API-1'"/><br>
                        <input type="submit" name="exampleModalToggle10" value="Фильтр 'API-0'"/><br>
                      </div>
                    </div>
                  </form>
                </li>
                  <li>
                    <form class="d-flex" method="POST" action="accounts.php">
                      <input class="form-control me-2" type="search" placeholder="Поиск" name="search" aria-label="Search">
                      <input class="btn btn-primary" type="submit" name='submit' value='Найти'>
                    </form>
                  </li>
                  <li>
                    <form class="d-flex" method="POST" action="accounts.php">
                      <input class="btn btn-primary" type="submit" name="back" value="Отменить поиск">
                    </form>
                  </li>
                </ul>
<br>
<br>
<table border="1" width="600" align="center" >
<tr>
<th>ID</th> 
<th>Логин</th>
<th>Пароль</th> 
<th>Ф.И.О.</th> 
<th>Телефон</th> 
<th>Доступ</th> 
<th>Уникальный API-ключ</th> 
<th>API-уровни доступа</th> 
<th>Ключи активации</th> 
</tr>
<?php
include 'loading.php';
?>
<?php
if(isset($_POST['submit'])){
  $s=$_POST['search'];
  $sql = ("SELECT * FROM `accounts` WHERE `id` LIKE '%$s%' OR `Логин` LIKE '%$s%' OR `ФИО` LIKE '%$s%' OR `Телефон` LIKE '$s' OR `pass` LIKE '$s' OR `api_key` LIKE '$s' OR `api_pass` LIKE '$s' OR `hash` LIKE '$s' OR `email_confirm` LIKE '$s'");
  $result1 = $db->query($sql);
}
else if(isset($_POST['back'])){ 
  $sql = ("SELECT * FROM `accounts`");
  $result1 = $db->query($sql);
}
else if( isset( $_POST['exampleModalToggle3'] ) )
{
  $sql = "SELECT * FROM accounts";
  $result1 = $db->query($sql);
}
else if( isset( $_POST['exampleModalToggle4'] ) )
{
  $sql = "SELECT * FROM accounts ORDER BY ФИО ASC";
  $result1 = $db->query($sql);
}

else if( isset( $_POST['exampleModalToggle5'] ) )
{
  $sql = "SELECT * FROM accounts ORDER BY Логин ASC";
  $result1 = $db->query($sql);
}

else if( isset( $_POST['exampleModalToggle6'] ) )
{
  $sql = "SELECT * FROM accounts WHERE pass='c4ca4238a0b923820dcc509a6f75849b'";
  $result1 = $db->query($sql);
}

else if( isset( $_POST['exampleModalToggle7'] ) )
{
  $sql = "SELECT * FROM accounts WHERE pass='cfcd208495d565ef66e7dff9f98764da'";
  $result1 = $db->query($sql);
}

else if( isset( $_POST['exampleModalToggle10'] ) )
{
  $sql = "SELECT * FROM accounts WHERE api_pass='cfcd208495d565ef66e7dff9f98764da'";
  $result1 = $db->query($sql);
}

else if( isset( $_POST['exampleModalToggle9'] ) )
{
  $sql = "SELECT * FROM accounts WHERE api_pass='c4ca4238a0b923820dcc509a6f75849b'";
  $result1 = $db->query($sql);
}
else if( isset( $_POST['exampleModalToggle8'] ) )
{
  $sql = "SELECT * FROM accounts WHERE api_pass='c81e728d9d4c2f636f067f89cc14862c'";
  $result1 = $db->query($sql);
}

else{
  $sql = "SELECT * FROM accounts";
  $result1 = $db->query($sql);
}
while ($row = $result1->fetch_assoc())
{
  if($row["id"]=="1"){

    echo "<tr>\n<td>".$row["id"]."</td>"."\n"."<td>"."".$row["Логин"]."
</td>"."\n"."<td>"."".$row["Пароль"]."</td>"."\n"."<td>"."".$row
["ФИО"]."</td>"."\n"."<td>"."".$row["Телефон"]."</td>"."\n"."<td>
"."".$row["pass"]."</td>"."\n"
."<td>"."".$row["api_key"]."</td>"."\n"
."<td>"."".$row["api_pass"]."</td>"."\n"
."<td>"."".$row["email_confirm"]."</td>";
  }
    else{
echo "<tr>\n<td>".$row["id"]."</td>"."\n"."<td>"."".$row["Логин"]."
</td>"."\n"."<td>"."".$row["Пароль"]."</td>"."\n"."<td>"."".$row
["ФИО"]."</td>"."\n"."<td>"."".$row["Телефон"]."</td>"."\n"."<td>
"."".$row["pass"]."</td>"."\n"
."<td>"."".$row["api_key"]."</td>"."\n"
."<td>"."".$row["api_pass"]."</td>"."\n"
."<td>"."".$row["email_confirm"]."</td>"."\n"
."<td>".""."<a href='edit_accounts.php?id1=".$row["id"]."' class='btn btn-primary'style=' font-size: 12px;'>Изменить</a>"."</td>"."\n"
."<td>".""."<a href='accounts.php?id2=".$row["id"]."' class='btn btn-primary'style=' font-size: 12px;'>Удалить</a>"."</td>";
}
}
?>

</table>
<br>
<?php    include 'footer.php'; 

if (isset($_GET['id2'])) {
    $id = $_GET['id2'];
    $db->query("DELETE FROM `accounts` WHERE `id` LIKE '$id'");
    echo "<script>
window.location.href='accounts.php'</script>";
}
?>







<div class="modal fade" id="exampleModalToggle2" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="exampleModalToggleLabel2">Добавление</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form method="POST" name="form" class="was-validated" >

<div class="form-group" >
<label > Логин:</label>
   <input name="login" type="text" class="form-control" title='Пример:primer@yandex.ru' id="exampleInputEmail1"  required pattern=".+@.+\..+" placeholder="Логин"><br>
   <label > Пароль:</label>
  <input name="password" type="password" class="form-control" title='A-Z,A-Я,_,.,0-9,a-z,a-я' id="exampleInputEmail2"  required pattern="[A-Za-zА-Яа-я0-9_.]{1,20}" placeholder="Пароль"><br>
<label > ФИО:</label>
  <input name="ФИО" type="text" class="form-control" id="exampleInputEmail3" title='A-Z,A-Я, ,a-z,a-я' required pattern="[A-Za-zА-Яа-я ]{1,85}" placeholder="ФИО"><br>
  <label > Телефон:</label>
  <input name="telephone" type="text" class="form-control" id="exampleInputEmail4" title='Пример:+7**********' required pattern="[+]+[7]+[0-9]{10,12}" placeholder="Телефон"><br>
<label > Права:</label>
  <select name="pass" selected value="0" class="form-select" >
  <option selected value="1">Админ</option>
   <option selected value="0">Пользователь</option>
</select><br>
<label > Права Доступа API:</label>
  <select name="api_pass" selected value="0" class="form-select" >
      <option selected value="0">Нет прав</option>
   <option selected value="1">Пользователь 1 уровня</option>
   <option selected value="2">Пользователь 2 уровня</option>
</select><br>

  </div>
<br>
<input class="btn btn-primary" name="do" type="submit" href="#" >
</form>
</div>
</div>
</div>
</div>

<?php

if(isset($_POST['do'])){
if(preg_match('/^.+@.+\..+$/u', $_POST['login'])==true){
if(preg_match('/^[A-Za-zА-Яа-я0-9_.]{1,20}$/u', $_POST['password'])==true){
if(preg_match('/^[A-Za-zА-Яа-я ]{1,85}$/u', $_POST['ФИО'])==true){
if(preg_match('/^[+]+[7]+[0-9]{10,12}$/u', $_POST['telephone'])==true){
$log=$_POST['login'];
$pas=MD5($_POST['password']);
$fio=$_POST['ФИО'];

$telephone=$_POST['telephone'];
$pass=MD5($_POST['pass']);
$api_pass=MD5($_POST['api_pass']);
if ($res=$db->query("SELECT * FROM `accounts` WHERE `Логин` LIKE '".$log."'")){
 $row_cnt = $res->num_rows;
 $res->close();}
  if($row_cnt > 0){
    echo "<script>alert('Пользователь с таким логином уже существует!')</script>";

$db->close();
  }
  else{
$db->query("INSERT INTO `accounts` (`id`, `Логин`, `Пароль`, `ФИО`, `Телефон`,`pass`,`api_key`,`api_pass`,`hash`,`email_confirm`) VALUES(NULL, '$log','$pas','$fio','$telephone','$pass',NULL,'$api_pass',NULL,NULL)");


echo "<script>
window.location.href='accounts.php'</script>";
}
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}
    ?>
</body>
</html>