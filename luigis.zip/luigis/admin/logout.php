<?php include 'session.php';


 unset($_SESSION['admin']);
 session_destroy();
 echo '<meta http-equiv="refresh" content="1; URL=../index.php" />';


?>