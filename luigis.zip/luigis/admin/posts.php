<?php
include 'session.php';

include 'security.php';
protect_page();
?> 
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<head><title>IL PIACERE:POSTS</title></head>
<?php

include 'head.php';
include 'header.php';
?>

<style>

  table {
  width: 100%;
  margin-bottom: 20px;
  border: 5px solid #fff;
  border-top: 5px solid #fff;
  border-bottom: 3px solid #fff;
  border-collapse: collapse; 
  outline: 3px solid #EF0031;
  font-size: 15px;
  background: #fff!important;
}
 th {
  font-weight: bold;
  padding: 7px;
  background: #EF0031;
  border: none;
  text-align: left;
  font-size: 15px;
  border-top: 3px solid #fff;
  border-bottom: 3px solid #EF0031;
  color:white!important;
}
 td {
  padding: 7px;
  border: none;
  border-top: 3px solid #fff;
  border-bottom: 3px solid #fff;
  font-size: 15px;

}
ul{text-align:center;}
ul li{display:inline-block;}
</style>
<body >
  <section class="bg-4 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                                <h5><b>ЛУЧШИЙ В ГОРОДЕ</b></h5>
                                <h2 class="mt-30 mb-15">POSTS</h2>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>
<br><br>
                <ul class="main-menu font-mountainsre" >

                        <li><a class="btn btn-primary" data-bs-toggle="modal" href="#exampleModalToggle2" role="button">Добавить</a></li>
                <li><a class ="btn btn-primary" href="p_posts.php"> Распечатать</a></li>
                <li><form method="POST"><div class="dropdown" >
  <button class="btn btn-secondary dropdown-toggle"  type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Фильтры и Сортировка
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <input type="submit" name="exampleModalToggle3" value="Все данные базы по ID" /><br>
<input type="submit" name="exampleModalToggle4" value="Сортировка по возростанию Дата" /><br>
<input type="submit" name="exampleModalToggle5" value="Сортировка по убыванию Дата" /><br>
<input type="submit" name="exampleModalToggle6" value="Сортировака по убыванию ID"/><br>
<input type="submit" name="exampleModalToggle7" value="Сортировка по возростанию Название"/><br>
<input type="submit" name="exampleModalToggle8" value="Сортировка по убыванию Название"/><br>
  </div>
</div></form></li>
<li><form class="d-flex" method="POST" action="posts.php">
        <input class="form-control me-2" type="search" placeholder="Поиск" name="search" aria-label="Search">
        <input class="btn btn-primary" type="submit" name='submit' value='Найти'>
      </form></li>
      <li><form class="d-flex" method="POST" action="posts.php">
        <input class="btn btn-primary" type="submit" name="back" value="Отменить поиск">
    </form></li>
                </ul>
  


<br><br>
<table border="1" width="600" align="center">
<tr >

<th>ID</th> 
<th>Название</th>
<th>Дата</th> 
<th>Описание</th> 
<th>Изображение</th> 
<th>id админа</th> 
</tr>


<?php
include 'loading.php';
?>
<?php
if(isset($_POST['submit'])){ 

$s=$_POST['search'];
$sql = ("SELECT * FROM `posts` WHERE `id` LIKE '%$s%' OR `Название` LIKE '%$s%' OR `Дата` LIKE '%$s%' OR `Описание` LIKE '%$s%'");
$result1 = $db->query($sql);
}
else if(isset($_POST['back'])){ 
  $sql = ("SELECT * FROM `posts`");
$result1 = $db->query($sql);
}

else if( isset( $_POST['exampleModalToggle3'] ) )
{
$sql = "SELECT * FROM posts";
$result1 = $db->query($sql);
}

else if( isset( $_POST['exampleModalToggle4'] ) )
{
$sql = "SELECT * FROM posts ORDER BY Дата ASC";
$result1 = $db->query($sql);
}

else if( isset( $_POST['exampleModalToggle5'] ) )
{
$sql = "SELECT * FROM posts ORDER BY Дата DESC";
$result1 = $db->query($sql);
}

else if( isset( $_POST['exampleModalToggle6'] ) )
{
$sql = "SELECT * FROM posts ORDER BY id DESC";
$result1 = $db->query($sql);
}

else if( isset( $_POST['exampleModalToggle7'] ) )
{
$sql = "SELECT * FROM posts ORDER BY Название ASC";
$result1 = $db->query($sql);
}
else if( isset( $_POST['exampleModalToggle8'] ) )
{
$sql = "SELECT * FROM posts ORDER BY Название DESC";
$result1 = $db->query($sql);
}
else{
  $sql = "SELECT * FROM posts";
$result1 = $db->query($sql);
}
while ($row = $result1->fetch_assoc())
{
echo "<tr>\n<td>".$row["id"]."</td>"."\n"
."<td>"."".$row["Название"]."</td>"."\n"
."<td>"."".$row["Дата"]."</td>"."\n"
."<td>"."".$row["Описание"]."</td>"."\n"
."<td><img src='../".$row["Изображение"]."' ></td>"."\n"
."<td>"."".$row["id_admin"]."</td>"."\n"
."<td>".""."<a href='edit_posts.php?id1=".$row["id"]."' class='btn btn-primary'>Изменить</a>"."</td>"."\n"
."<td>".""."<a href='posts.php?id2=".$row["id"]."' class='btn btn-primary'>Удалить</a>"."</td>";
}

?>

</table>
<br>
<?php    include 'footer.php'; 
if (isset($_GET['id2'])) {
    $id = $_GET['id2'];

$res = $db->query("SELECT * FROM `posts` WHERE `id` LIKE '".$id."' ");
while($row=$res->fetch_assoc()) {
$iso=$row["Изображение"];
}
unlink("../".$iso);
    $db->query("DELETE FROM `posts` WHERE `id` LIKE '$id'");
    echo "<script>
window.location.href='posts.php'</script>";
}
?>






<div class="modal fade" id="exampleModalToggle2" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="exampleModalToggleLabel2">Добавление</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form method="POST" class="was-validated" ENCTYPE="multipart/form-data">

<div class="form-group" >
<label > Название:</label>
   <input name="name" type="text" class="form-control" id="exampleInputEmail1" title='A-Z,a-z, ,а-я,.,_,A-Я (20 символов)' required pattern="[A-Za-zА-Яа-я0-9_. ]{1,100}" placeholder="Название"><br>
   <label > Описание:</label>
  <input name="tex" type="text" class="form-control" id="exampleInputEmail2" title='A-Z,a-z, ,а-я,.,_,A-Я (100 символов)' required pattern="[A-Za-zА-Яа-я0-9_., ]{1,200}" placeholder="Описание"><br>
  <label > Изображение:</label>
<input name="userfile" type="file" multiple accept="image/*"  class="form-control" >




  </div>
<br>
<input class="btn btn-primary" name="do" type="submit"  >
</form>
</div>
</div>
</div>
</div>
<?php 
$uploaddir = '../images/posts/';
$apend=date('YmdHis').rand(100,1000).'.jpg'; 
$uploadfile = "$uploaddir$apend"; 
if(($_FILES['userfile']['type'] == 'image/gif' || $_FILES['userfile']['type'] == 'image/jpeg' || $_FILES['userfile']['type'] == 'image/png') && ($_FILES['userfile']['size'] != 0)) 
{ 
  if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile))  
   { 

   }
}
else{
       $apend="";
   } 
if(isset($_POST['do'])){
if(preg_match('/^[A-Za-zА-Яа-я0-9_., ]{1,300}$/u', $_POST['name'])==true){
  if(preg_match('/^[A-Za-zА-Яа-я0-9_., ]{1,300}$/u', $_POST['tex'])==true){
$na=$_POST['name'];
$te=$_POST['tex'];
$imag="images/posts/".$apend;
$ad_id=$_SESSION['ad_id'];

   $db->query("INSERT INTO `posts` (`id`, `Название`, `Дата`, `Описание`, `Изображение`,`id_admin`) VALUES(NULL, '$na',NOW(),'$te','$imag',$ad_id)");
echo "<script>
window.location.href='posts.php'</script>";
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}
 ?>
</body>
</html>
