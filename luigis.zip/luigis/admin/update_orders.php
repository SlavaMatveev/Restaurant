<?php
include 'session.php';
include 'loading.php';
include 'security.php';
protect_page();
?>


<?php
if(isset($_POST['do'])){
$id=$_GET['id'];
if(preg_match('/^[+]+[7]+[0-9]{10,12}$/u', $_POST['tel'])==true){
$adr=$_POST['adress'];

$telephone=$_POST['tel'];
$gt=$_POST['gt'];
if($gt=='да'){
	$result=$db->query("UPDATE `orders` SET `Адрес`='$adr',`Телефон клиента`='$telephone',`Готово`=NOW() WHERE `Номер заказа`='$id'");
}
if($gt=='нет'){
	$result=$db->query("UPDATE `orders` SET `Адрес`='$adr',`Телефон клиента`='$telephone',`Готово`=NULL WHERE `Номер заказа`='$id'");
}
if($result){
          }
          else{
            echo $conn->error;
          }

}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
    }
    echo "<script>
window.location.href='orders.php'</script>";


    ?>