<?php
include 'session.php';
include 'loading.php';
include 'security.php';
protect_page();
?>


<?php
if(isset($_POST['do'])){
$id=explode("=",$_SERVER["QUERY_STRING"])[1];
if(preg_match('/^[A-Za-zА-Яа-я]{1,85}$/u', $_POST['Вид'])==true){
if(preg_match('/^[0-9]{0,11}$/u', $_POST['count'])==true){
$vid=$_POST['Вид'];
$count=$_POST['count'];

$result=$db->query("UPDATE `view` SET Вид='$vid',count='$count' WHERE id='$id'");
if($result){
          }
          else{
            echo $conn->error;
          }
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
    }
    echo "<script>
window.location.href='view.php'</script>";


    ?>