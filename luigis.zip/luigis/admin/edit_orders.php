<?php
include 'session.php';
include 'loading.php';
include 'security.php';
protect_page();
$id=$_GET["id1"];

?>

<!DOCTYPE html>
<html lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"><head><title>IL PIACERE:ORDERS:Изменение</title></head>
<?php

include 'head.php';
include 'header.php';
?>

<section class="bg-4 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                                <h5><b>ЛУЧШИЙ В ГОРОДЕ</b></h5>
                                <h2 class="mt-30 mb-15" id="exampleModalToggleLabel2">ORDERS:Изменение</h2>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>
<?php
echo "<form class='was-validated' method='POST' name='form' action='update_orders.php?id=$id'>";

$row = $db->query("SELECT * FROM orders WHERE `Номер заказа`='$id'");
$row = $row->fetch_assoc();


echo "<label > Телефон:</label>";
echo "<input name='tel' value='".$row["Телефон клиента"]."' type='text' class='form-control' title='+7**********' required pattern='[+]+[7]+[0-9]{10,12}' id='exampleInputEmail4' placeholder='Телефон'><br>";
echo "<label > Адрес:</label>";
echo "<input name='adress' value='".$row["Адрес"]."' type='text' class='form-control' id='exampleInputEmail3' required  placeholder='Адрес'><br>";
echo "<label > Готово:</label>";
echo "<select name='gt' selected value='".$row["Готово"]."' class='form-select' >";
echo "<option  value='да'>Да</option>";
echo "<option  value='нет'>Нет</option>";
echo "</select><br>";
?>
  </div>
<br>
<input class="btn btn-primary" style="position: relative;left: 50%;transform: translate(-50%, 0);" name="do" type="submit" href="#" >
<br><br>
<?php include 'footer.php'; ?>
</form>



