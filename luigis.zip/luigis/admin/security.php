<?php
                    function protect_page(){
if (logged_in() === false ) {
            echo "<script>alert('У вас должны быть права администратора!');window.location.href='../index.php';</script>"; 
        }
    }
function logged_in(){
        return(isset($_SESSION['ad_id'])) ? true : false;
    }
            ?>