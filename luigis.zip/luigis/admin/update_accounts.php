<?php
include 'session.php';
include 'loading.php';
include 'security.php';
protect_page();
?>


<?php
if(isset($_POST['do'])){
$id=$_GET['id'];
if(preg_match('/^[A-Za-zА-Яа-я0-9_.]{0,20}$/u', $_POST['password'])==true){
if(preg_match('/^[A-Za-zА-Яа-я ]{1,85}$/u', $_POST['ФИО'])==true){
if(preg_match('/^[+]+[7]+[0-9]{10,12}$/u', $_POST['telephone'])==true){

 $pas=$_POST['password'];
 $fio=$_POST['ФИО'];
 $activ=MD5($_POST['activ']);
 $telephone=$_POST['telephone'];
 $pass=MD5($_POST['pass']);
 $api_pass=MD5($_POST['api_pass']);
if($pas==""){

  $result=$db->query("UPDATE `accounts` SET `ФИО`='$fio',`api_pass`='$api_pass',`Телефон`='$telephone',`pass`='$pass',`email_confirm`='$activ' WHERE `id` LIKE '$id'");
echo '<meta http-equiv="refresh" content="1; URL=accounts.php" />';
}else{

  $pas=MD5($pas);
$result=$db->query("UPDATE `accounts` SET `Пароль`='$pas',`ФИО`='$fio',`api_pass`='$api_pass',`Телефон`='$telephone',`pass`='$pass',`email_confirm`='$activ' WHERE `id` LIKE '$id'");

echo '<meta http-equiv="refresh" content="1; URL=accounts.php" />';
}


    
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}

}

    ?>