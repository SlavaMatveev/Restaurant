<?php
include 'session.php';
include 'security.php';

protect_page();
?> 
<!DOCTYPE html>
<html lang="en"><head><title>IL PIACERE:VIEW</title></head>
<?php

include 'head.php';
include 'header.php';

?>

<style>

  table {
  width: 100%;
  margin-bottom: 20px;
  border: 5px solid #fff;
  border-top: 5px solid #fff;
  border-bottom: 3px solid #fff;
  border-collapse: collapse; 
  outline: 3px solid #EF0031;
  font-size: 15px;
  background: #fff!important;
}
 th {
  font-weight: bold;
  padding: 7px;
  background: #EF0031;
  border: none;
  text-align: center;
  font-size: 15px;
  border-top: 3px solid #fff;
  border-bottom: 3px solid #EF0031;
  color:white!important;
}
 td {
  padding: 7px;
  border: none;
    text-align: center;
  border-top: 3px solid #fff;
  border-bottom: 3px solid #fff;
  font-size: 15px;

}
ul{text-align:center;}
ul li{display:inline-block;}
</style>
<body >

  <section class="bg-4 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                                <h5><b>ЛУЧШИЙ В ГОРОДЕ</b></h5>
                                <h2 class="mt-30 mb-15">VIEW</h2>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>
<br><br>
                <ul class="main-menu font-mountainsre" >

                        <li><a class="btn btn-primary" data-bs-toggle="modal" href="#exampleModalToggle2" role="button">Добавить</a></li>
                <li><a class ="btn btn-primary" href="p_view.php"> Распечатать</a></li>
                <li><form method="POST"><div class="dropdown" >
  <button class="btn btn-secondary dropdown-toggle"  type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Фильтры и Сортировка
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <input type="submit" name="exampleModalToggle3" value="Все данные базы по ID" /><br>
<input type="submit" name="exampleModalToggle4" value="Сортировка по id по убыванию" /><br>
<input type="submit" name="exampleModalToggle5" value="Сортировка по возрастанию колличества" /><br>
<input type="submit" name="exampleModalToggle6" value="Сортировка по убыванию колличества"/><br>
<input type="submit" name="exampleModalToggle7" value="Сортировка по Виду"/><br>
  </div>
</div></form></li>
<li><form class="d-flex" method="POST" action="view.php">
        <input class="form-control me-2" type="search" placeholder="Поиск" name="search" aria-label="Search">
        <input class="btn btn-primary" type="submit" name='submit' value='Найти'>
      </form></li>
      <li><form class="d-flex" method="POST" action="view.php">
        <input class="btn btn-primary" type="submit" name="back" value="Отменить поиск">
    </form></li>
                </ul>
  


<br><br>
<table border="1" width="600" align="center">
<tr >

<th>ID</th> 
<th>Колличество</th>
<th>Вид</th> 

</tr>


<?php

include 'loading.php';
?>
<?php
if(isset($_POST['submit'])){ 
$s=$_POST['search'];
$sql = ("SELECT * FROM `view` WHERE `id` LIKE '%$s%' OR `count` LIKE '%$s%' OR `Вид` LIKE '%$s%'");
$result1 = $db->query($sql);
}
else if(isset($_POST['back'])){ 
  $sql = ("SELECT * FROM `view`");
$result1 = $db->query($sql);
}

else if( isset( $_POST['exampleModalToggle3'] ) )
{
$sql = "SELECT * FROM view";
$result1 = $db->query($sql);
}

else if( isset( $_POST['exampleModalToggle4'] ) )
{
$sql = "SELECT * FROM view ORDER BY id DESC";
$result1 = $db->query($sql);
}

else if( isset( $_POST['exampleModalToggle5'] ) )
{
$sql = "SELECT * FROM view ORDER BY count ASC";
$result1 = $db->query($sql);
}

else if( isset( $_POST['exampleModalToggle6'] ) )
{
$sql = "SELECT * FROM view ORDER BY count DESC";
$result1 = $db->query($sql);
}

else if( isset( $_POST['exampleModalToggle7'] ) )
{
$sql = "SELECT * FROM view ORDER BY Вид ASC";
$result1 = $db->query($sql);
}
else{
  $sql = "SELECT * FROM view";
$result1 = $db->query($sql);
}
while ($row = $result1->fetch_assoc())
{

echo "<tr>\n<td>".$row["id"]."</td>"."\n"."<td>"."".$row["count"]."
</td>"."\n"."<td>"."".$row["Вид"]."</td>"."\n"
."<td>".""."<a href='edit_view.php?id1=".$row["id"]."' class='btn btn-primary'>Изменить</a>"."</td>"."\n"
."<td>".""."<a href='view.php?id2=".$row["id"]."' class='btn btn-primary'>Удалить</a>"."</td>";
}

?>

</table>
<br>

<?php 
  include 'footer.php'; 
if (isset($_GET['id2'])) {
    $id = $_GET['id2'];
    $db->query("DELETE FROM `view` WHERE `id` LIKE '$id'");
    echo "<script>
window.location.href='view.php'</script>";
}
  ?>






<div class="modal fade" id="exampleModalToggle2" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="exampleModalToggleLabel2">Добавление</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form method="POST" name="form" class="was-validated" >

<div class="form-group">

<label > Вид:</label>
  <input name="Вид" type="text" class="form-control" id="exampleInputEmail1"  required pattern="[A-Za-zА-Яа-я]{1,85}" placeholder="Вид"><br>
  <label > Колличество:</label>
  <input name="count" type="text" class="form-control" id="exampleInputEmail2"  required pattern="[0-9]{0,11}" placeholder="Колличество"><br>
</select><br>
  </div>
<br>
<input class="btn btn-primary" name="do" type="submit" href="#" >
</form>
</div>
</div>
</div>
</div>

<?php

if(isset($_POST['do'])){
if(preg_match('/^[A-Za-zА-Яа-я]{1,85}$/u', $_POST['Вид'])==true){
if(preg_match('/^[0-9]{0,11}$/u', $_POST['count'])==true){
$vid=$_POST['Вид'];
$count=$_POST['count'];


$telephone=$_POST['telephone'];
$pass=MD5($_POST['pass']);
$db->query("INSERT INTO `view` (`id`, `count`, `Вид`) VALUES(NULL, '$count','$vid')");

echo "<script>
window.location.href='view.php'</script>";
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
    }

    ?>




</body>
</html>