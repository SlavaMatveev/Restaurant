<?php
include 'session.php';
include 'security.php';
protect_page();

?> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<?php
include "head.php";
?>

<head><title>IL PIACERE:ADMINISTRATION</title></head>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html>
<head>
<meta charset="UTF-8" />
</head>
<body >
<?php
include "header.php";
?>
<section class="bg-4 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                                <h5><b>ЛУЧШИЙ В ГОРОДЕ</b></h5>
                                <h2 class="mt-30 mb-15">ADMINISTRATION</h2>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>
<h3 style="text-align:center;margin:15%;">Добро пожаловать в базу данных IL PIACERE!</h3>

<?php
include "footer.php";
?>
</body>
</html>