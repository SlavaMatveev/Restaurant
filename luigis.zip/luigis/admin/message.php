<?php
include 'session.php';

include 'security.php';
protect_page();
?> 
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"><head><title>IL PIACERE:MESSAGE</title></head>
<?php

include 'head.php';
include 'header.php';
?>

<style>

  table {
  width: 100%;
  margin-bottom: 20px;
  border: 5px solid #fff;
  border-top: 5px solid #fff;
  border-bottom: 3px solid #fff;
  border-collapse: collapse; 
  outline: 3px solid #EF0031;
  font-size: 15px;
  background: #fff!important;
}
 th {
  font-weight: bold;
  padding: 7px;
  background: #EF0031;
  border: none;
  text-align: left;
  font-size: 15px;
  border-top: 3px solid #fff;
  border-bottom: 3px solid #EF0031;
  color:white!important;
}
 td {
  padding: 7px;
  border: none;
  border-top: 3px solid #fff;
  border-bottom: 3px solid #fff;
  font-size: 15px;

}
ul{text-align:center;}
ul li{display:inline-block;}
</style>
<body >
  <section class="bg-4 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                                <h5><b>ЛУЧШИЙ В ГОРОДЕ</b></h5>
                                <h2 class="mt-30 mb-15">MESSAGE</h2>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>
<br><br>
                <ul class="main-menu font-mountainsre" >


                <li><a class ="btn btn-primary" href="p_message.php"> Распечатать</a></li>
                <li><form method="POST"><div class="dropdown" >
  <button class="btn btn-secondary dropdown-toggle"  type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Фильтры и Сортировка
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <input type="submit" name="exampleModalToggle3" value="Все данные базы по ID" /><br>
<input type="submit" name="exampleModalToggle4" value="Сортировка по возрастанию Название" /><br>
<input type="submit" name="exampleModalToggle6" value="Сортировка по убыванию ID"/><br>
<input type="submit" name="exampleModalToggle8" value="Сортировка по убыванию Название"/><br>
  </div>
</div></form></li>
<li><form class="d-flex" method="POST" action="message.php">
        <input class="form-control me-2" type="search" placeholder="Поиск" name="search" aria-label="Search">
        <input class="btn btn-primary" type="submit" name='submit' value='Найти'>
      </form></li>
      <li><form class="d-flex" method="POST" action="message.php">
        <input class="btn btn-primary" type="submit" name="back" value="Отменить поиск">
    </form></li>
                </ul>
  


<br><br>
<table border="1" width="600" align="center">
<tr >

<th>ID</th> 
<th>Название</th>
<th>Комментарий</th> 
<th>id_client</th> 
</tr>


<?php
include 'loading.php';
?>
<?php
if(isset($_POST['submit'])){ 

$s=$_POST['search'];
$sql = ("SELECT * FROM `message` WHERE `id` LIKE '%$s%' OR `Название` LIKE '%$s%' OR `Комментарий` LIKE '%$s%' OR `ФИО` LIKE '%$s%'");
$result1 = $db->query($sql);
}
else if(isset($_POST['back'])){ 
  $sql = ("SELECT * FROM `message`");
$result1 = $db->query($sql);
}
  


else if( isset( $_POST['exampleModalToggle3'] ) )
{
$sql = "SELECT * FROM message";
$result1 = $db->query($sql);
}

else if( isset( $_POST['exampleModalToggle4'] ) )
{
$sql = "SELECT * FROM message ORDER BY Название ASC";
$result1 = $db->query($sql);
}



else if( isset( $_POST['exampleModalToggle6'] ) )
{
$sql = "SELECT * FROM message ORDER BY id DESC";
$result1 = $db->query($sql);
}


else if( isset( $_POST['exampleModalToggle8'] ) )
{
$sql = "SELECT * FROM message ORDER BY Название DESC";
$result1 = $db->query($sql);
}
else{
  $sql = "SELECT * FROM message";
$result1 = $db->query($sql);
}
while ($row = $result1->fetch_assoc())
{
echo "<tr>\n<td>".$row["id"]."</td>"."\n".
"<td>"."".$row["Название"]."</td>"."\n".
"<td>"."".$row["Комментарий"]."</td>"."\n".
"<td>"."".$row["id_client"]."</td>"."\n".
"<td>".""."<a href='edit_message.php?id1=".$row["id"]."' class='btn btn-primary'>Изменить</a>"."</td>"."\n"
."<td>".""."<a href='message.php?id2=".$row["id"]."' class='btn btn-primary'>Удалить</a>"."</td>";
}

?>

</table>
<br>
<?php    include 'footer.php'; 

if (isset($_GET['id2'])) {
    $id = $_GET['id2'];
    $db->query("DELETE FROM `message` WHERE `id` LIKE '$id'");
    echo "<script>
window.location.href='message.php'</script>";
}
?>










</body>
</html>