<?php
$db = mysqli_connect('localhost', 'n91541mu_il_piac', 'a1A1111', 'n91541mu_il_piac');
?>