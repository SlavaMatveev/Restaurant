<?php $status=session_status();
if($status == PHP_SESSION_NONE){
session_start();
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">