<?php
include 'session.php';
include 'loading.php';
include 'security.php';
protect_page();
?>


<?php
if(isset($_POST['do'])){
$id=$_GET['id'];
if(preg_match('/^[A-Za-zА-Яа-я0-9_., ]{1,20}$/u', $_POST['name'])==true){
if(preg_match('/^[A-Za-zА-Яа-я0-9_., ]{1,100}$/u', $_POST['comm'])==true){
$com=$_POST['comm'];
$nam=$_POST['name'];


$result=$db->query("UPDATE `message` SET Название='$nam',Комментарий='$com' WHERE id='$id'");
if($result){
          }
          else{
            echo $conn->error;
          }
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
}else{ echo "<script>alert('Некорректный ввод данных, попробуйте ещё раз!');</script>";}
    }
    echo "<script>
window.location.href='message.php'</script>";


    ?>