<?php
include 'session.php';
include 'loading.php';
include 'security.php';
protect_page();
$id=$_GET["id1"];
?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?php


include 'head.php';
include 'header.php';
?>
<head><title>IL PIACERE:ACCOUNTS:Изменение</title></head>
<section class="bg-4 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                                <h5><b>ЛУЧШИЙ В ГОРОДЕ</b></h5>
                                <h2 class="mt-30 mb-15" id="exampleModalToggleLabel2">ACCOUNTS:Изменение</h2>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>

<?php
echo "<form method='POST' class='was-validated' name='form' action='update_accounts.php?id=$id'>";
$row = $db->query("SELECT * FROM accounts WHERE id='$id'");
$row = $row->fetch_assoc();
?>
<div class="form-group">


<?php
echo "<label > Пароль:</label>";
  echo "<input name='password'  type='password' class='form-control' title='A-Z,a-z,A-Я,а-я,_,0-9 (20 символов)' id='exampleInputEmail2'   pattern='[A-Za-zА-Яа-я0-9_.]{0,20}'' placeholder='Пароль'><br>";
echo "<label > ФИО:</label>";
 echo "<input name='ФИО' value='".$row["ФИО"]."' type='text' class='form-control' id='exampleInputEmail3' title='A-Z,a-z,A-Я,а-я, ,(85 символов)' required pattern='[A-Za-zА-Яа-я ]{1,85}' placeholder='ФИО'><br>";
 echo "<label > Телефон:</label>";
 echo "<input name='telephone' value='".$row["Телефон"]."' type='text' class='form-control' id='exampleInputEmail4' title='Пример:+7**********' required pattern='[+]+[7]+[0-9]{10,12}' placeholder='Телефон'><br>";
echo "<label > Права:</label>";
echo "<select name='pass'  selected value='".$row["pass"]."' class='form-select' >";
 echo "<option  value='1'>Админ</option>";
 echo  "<option  value='0'>Пользователь</option>";
echo "</select><br>";
echo "<label > Права Доступа API:</label>";
 echo " <select name='api_pass' selected value='0' class='form-select' >";
   echo " <option  value='0'>Нет прав</option>";
  echo " <option  value='1'>Пользователь 1 уровня</option>";
  echo " <option  value='2'>Пользователь 2 уровня</option>";
echo " </select><br>";
echo "<label > Активация:</label>";
 echo " <select name='activ' selected value='0' class='form-select' >";
   echo " <option  value='0'>Не активирован</option>";
  echo " <option  value='1'>Активирован</option>";

echo " </select><br>";
?>


  </div>
<br>
<input class="btn btn-primary" style="position: relative;left: 50%;transform: translate(-50%, 0);" name="do" type="submit" >
<br><br>
<?php include 'footer.php'; ?>
</form>



