<?php
include 'session.php';
include 'loading.php';
include 'security.php';
protect_page();
$id=$_GET["id1"];
?>

<!DOCTYPE html>
<html lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"><head><title>IL PIACERE:MESSAGE:Изменение</title></head>
<?php

include 'head.php';
include 'header.php';
?>

<section class="bg-4 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                                <h5><b>ЛУЧШИЙ В ГОРОДЕ</b></h5>
                                <h2 class="mt-30 mb-15" id="exampleModalToggleLabel2">MESSAGE:Изменение</h2>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>

<?php
echo "<form method='POST' class='was-validated' name='form' action='update_message.php?id=$id'>";
$row = $db->query("SELECT * FROM message WHERE id='$id'");
$row = $row->fetch_assoc();

echo "<label > Название:</label>";
  echo "<input name='name' value='".$row["Название"]."' type='text' class='form-control' title='A-Z,a-z,A-Я, ,а-я (85 символов)' id='exampleInputEmail2'  required pattern='[A-Za-zА-Яа-я0-9_., ]{1,20}' placeholder='Название'><br>";
echo "<label > Комментарий:</label>";
echo "<input name='comm' value='".$row["Комментарий"]."' type='text' class='form-control' id='exampleInputEmail3' title='A-Z,a-z,A-Я, ,а-я (85 символов)' required pattern='[A-Za-zА-Яа-я0-9_., ]{1,100}' placeholder='Комментарий'><br>";
echo "</select><br>";
?>


  </div>
<br>
<input class="btn btn-primary" style="position: relative;left: 50%;transform: translate(-50%, 0);" name="do" type="submit" href="#" >
<br><br>
<?php include 'footer.php'; ?>
</form>



