<?php 
include 'session.php';
include 'security.php';
protect_page();
unset($_SESSION['cart']);
unset($_SESSION['arr']);
 ?>
 <head><title>IL PIACERE:Ваш заказ принят</title></head>
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <link rel="icon" href="images/heading.ico" type="image/x-icon">
<html>
<head>

<style>
.button {
  padding: 10px 20px;
  font-size: 15px;
  text-align: center;

  cursor: pointer;
  outline: none;
  color: #EF0031;
  background-color: white;
  border: 1px solid #EF0031;

}
 .button:hover {background-color: #EF0031;
color: white;
 }

.button:active {
  background-color: #EF0031;
  border: 1px solid white;
  transform: translateY(4px);
}
.button1{

  border-radius: 50%; 
  width: 45px;
  height: 45px;
}
.buttong {
  padding: 10px 20px;
  font-size: 15px;
  text-align: center;

  cursor: pointer;
  outline: none;
  color: #3e8e41;
  background-color: white;
  border: 1px solid #3e8e41;

}
 .buttong:hover {background-color: #3e8e41;
color: white;
 }

.buttong:active {
  background-color: #3e8e41;
  border: 1px solid white;
  transform: translateY(4px);
}
</style>
<section class="bg-5 h-500x main-slider pos-relative">
        <div class="triangle-up pos-bottom"></div>
        <div class="container h-100">
                <div class="dplay-tbl">
                        <div class="dplay-tbl-cell center-text color-white pt-90">
                                <h2 class="mt-30 mb-15">Making an Order</h2>
                        </div><!-- dplay-tbl-cell -->
                </div><!-- dplay-tbl -->
        </div><!-- container -->
</section>
</head>
<body>
<?php
include('header.php');
?>
<div class="container">
<h3>Ваш заказ принят! Мы с вами свяжемся, когда заказ будет готов к выдаче</h3>



<a class="button" style="position: relative;left: 50%;transform: translate(-50%, 0);" href="index.php">Вернуться на главную</a>
<br><br>
</div>
<?php
include('footer.php');
?>
</body>
</html>