-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Июн 05 2022 г., 20:38
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `n91541mu_il_piac`
--

-- --------------------------------------------------------

--
-- Структура таблицы `accounts`
--
-- Создание: Май 26 2022 г., 15:40
-- Последнее обновление: Июн 05 2022 г., 11:29
--

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `Логин` varchar(255) NOT NULL,
  `Пароль` varchar(255) NOT NULL,
  `ФИО` varchar(255) NOT NULL,
  `Телефон` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL DEFAULT 'cfcd208495d565ef66e7dff9f98764da',
  `api_key` varchar(255) DEFAULT NULL,
  `api_pass` varchar(255) DEFAULT 'cfcd208495d565ef66e7dff9f98764da',
  `hash` varchar(255) DEFAULT NULL,
  `email_confirm` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `accounts`
--

INSERT INTO `accounts` (`id`, `Логин`, `Пароль`, `ФИО`, `Телефон`, `pass`, `api_key`, `api_pass`, `hash`, `email_confirm`) VALUES
(1, 'matvo@ya.ru', '827ccb0eea8a706c4c34a16891f84e7b', 'ADMIN', '+79154114246', 'c4ca4238a0b923820dcc509a6f75849b', '1', 'c81e728d9d4c2f636f067f89cc14862c', NULL, '1'),
(33, 'matveev-vo@ya.ru', '698d51a19d8a121ce581499d7b701668', 'Матвеев Вячеслав Олегович', '+79854306992', 'cfcd208495d565ef66e7dff9f98764da', NULL, 'cfcd208495d565ef66e7dff9f98764da', '14db0d69be57d4ded87edeee6fb9c5ba', 'c4ca4238a0b923820dcc509a6f75849b'),
(34, 's.j.shum@yandex.ru', '827ccb0eea8a706c4c34a16891f84e7b', 'Test Test Test', '+79999999999', 'cfcd208495d565ef66e7dff9f98764da', '538cafbfab32c7bceee8a9fc1dc78713', 'c81e728d9d4c2f636f067f89cc14862c', 'd1d5bb6385d2ad4c8e2071d27a76dffd', 'c4ca4238a0b923820dcc509a6f75849b');

-- --------------------------------------------------------

--
-- Структура таблицы `catalog`
--
-- Создание: Июн 04 2022 г., 11:40
-- Последнее обновление: Июн 05 2022 г., 11:13
--

DROP TABLE IF EXISTS `catalog`;
CREATE TABLE `catalog` (
  `id` int(11) NOT NULL,
  `Наименование` varchar(255) NOT NULL,
  `Вид` int(11) NOT NULL,
  `Описание` text NOT NULL,
  `Изображение` text CHARACTER SET utf8 COLLATE utf8_estonian_ci NOT NULL,
  `Цена` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `catalog`
--

INSERT INTO `catalog` (`id`, `Наименование`, `Вид`, `Описание`, `Изображение`, `Цена`) VALUES
(1, 'Маргарита', 1, 'Помидоры, сыр Моцарелла, фирменный соус', 'images/catalog/pizza/seller-7-200x200.png', '470.00'),
(2, 'Ветчина и сыр', 1, 'Ветчина, фирменный соус, соус 999 островов, сыр Моцарелла', 'images/catalog/pizza/seller-3-200x200.png', '399.00'),
(3, 'Четыре сыра', 1, 'Сыр Моцарелла, сыр Гауда, сыр Сулугуни, сыр Голландский, фирменный томатный соус', 'images/catalog/pizza/4_syra.png', '709.00'),
(4, 'Итальянская', 1, 'Ветчина, пепперони, фирменный соус, сыр Моцарелла', 'images/catalog/pizza/italya.png', '399.00'),
(5, 'Карбонара', 2, 'Паста алла карбонара представляет собой спагетти, приготовленные с мелкими ломтиками обжаренного бекона и смешанные со специальным соусом из сырых яиц, сыров пекорино романо и пармезана, свежемолотого черного перца и соли', 'images/catalog/pasta/Карбонара.png', '188.00'),
(6, 'Болоньезе', 2, 'Панчетта, говядина, свинина, лук, морковь, сельдерей, томаты, мясной бульон, красное вино, оливковое масло и паста тальятелле, ещё могут добавляться молоко или сливки, традиционный соус Болоньезе требует довольно много времени на его приготовление, он тушится около 4-х часов', 'images/catalog/pasta/pasta-1-300x300.png', '355.00'),
(7, 'Равиоли', 2, 'По древним итальянским традициям, это блюдо изготавливается только из муки, для производства которой используются твердые сорта пшеницы, при этом фарш может быть самым разнообразным, для него используют мясо, рыбу, овощи, сыр, грибы, зелень, если продукт готовится в качестве сладкого блюда, его начиняют фруктами, ягодами и прочими подходящими продуктами', 'images/catalog/pasta/Равиоли.png', '439.00'),
(8, 'Ньокки', 2, 'Клецки - это маленькие итальянские клецки, приготовленные из пшеничной муки, яиц и вареного картофеля. Ингредиенты смешивают, раскатывают в бревна, нарезают небольшими кусочками и затем отваривают,по желанию в смесь можно добавить тыкву и шпинат, блюдо появилось в 16 веке, когда картофель был завезен из Америки', 'images/catalog/pasta/Ньокки.png', '135.00'),
(9, 'Арлетт', 3, 'Куриное филе, шампиньоны, помидор, яйцо, репчатый лук, растительное масло, соль, чёрный молотый перец, майонез, зелень', 'images/catalog/salads/Арлетт.png', '149.00'),
(10, 'Капрезе', 3, 'помидоры,моцарелла,бальзамический уксус,\r\nрастительное масло,зелень базилика,соль,свежемолотый перец', 'images/catalog/salads/salat.png', '350.00'),
(11, 'Цезарь', 3, 'Крупное куриное филе,перепелиные яйца,листовой салат,помидоры черри,твердый сыр\r\nСоус:\r\nчеснок,растительное масло,горчица,майонез,соль,перец', 'images/catalog/salads/Цезарь.png', '453.00'),
(12, 'Зуппа ди пеше', 4, 'суповая рыба,креветки,моллюски,лук,чеснок,петрушка,миндаль,томатный концентрат,палочка корицы,лавровый лист,лимон,EVO', 'images/catalog/seafood/зуппа_ди_пеше.png', '1300.00'),
(13, 'Креветки в горгонзоле', 4, 'креветки,сливки,сливочное масло,оливковое масло,чеснок,сыр горгонзола,тимьян,французский багет', 'images/catalog/seafood/креветки в горгонзоле.png', '700.00'),
(14, 'Сырный суп с морепродуктами', 4, 'Плавленый сыр, Картофель, репчатый лук, морковь, растительное масло, креветки, соль, чёрный молотый перец, зелень, лавровый лист', 'images/catalog/seafood/Сырный суп с морепродуктами.png', '460.00'),
(15, 'Томатный суп с морепродуктами', 4, 'помидоры, креветки, мидии, лук, чеснок, морковь, сельдерей, картофель, тимьян, мята сухая', 'images/catalog/seafood/Томатный суп с морепродуктами.png', '380.00'),
(16, 'Джелато', 5, 'Итальянский замороженный десерт из свежего коровьего молока и сахара, с добавлением ягод, орехов, шоколада и свежих фруктов', 'images/catalog/dessert/Gelato.png', '430.00'),
(17, 'Панна котта', 5, 'Североитальянский десерт из сливок, сахара, желатина и ванили, родиной десерта является итальянский Пьемонт, дословный перевод этого лакомства с итальянского языка звучит как «варёные сливки», однако это скорее сливочный пудинг или просто сливочное желе с добавлением разных ингредиентов', 'images/catalog/dessert/Panna-Cotta.png', '560.00'),
(18, 'Тирамису', 5, 'Итальянский десерт со вкусом кофе, он сделан из дамских пальчиков, обмакнутых в кофе, посыпанных взбитой смесью яиц, сахара и сыра маскарпоне, приправленной какао', 'images/catalog/dessert/tiramisu.png', '600.00');

-- --------------------------------------------------------

--
-- Структура таблицы `message`
--
-- Создание: Июн 04 2022 г., 10:33
-- Последнее обновление: Июн 05 2022 г., 11:19
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE `message` (
  `id` int(11) NOT NULL,
  `Название` varchar(255) NOT NULL,
  `Комментарий` text NOT NULL,
  `id_client` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--
-- Создание: Июн 04 2022 г., 10:34
-- Последнее обновление: Июн 05 2022 г., 11:39
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `Номер заказа` int(11) NOT NULL,
  `Телефон клиента` varchar(255) NOT NULL,
  `Адрес` text NOT NULL,
  `Сумма к оплате` decimal(10,2) NOT NULL,
  `Принято` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Готово` datetime DEFAULT NULL,
  `id_client` int(11) NOT NULL,
  `order_num` int(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`Номер заказа`, `Телефон клиента`, `Адрес`, `Сумма к оплате`, `Принято`, `Готово`, `id_client`, `order_num`) VALUES
(55, '+79999999999', 'Химки Репина 7', '1108.00', '2022-06-05 14:39:52', NULL, 34, 755110382);

-- --------------------------------------------------------

--
-- Структура таблицы `order_prod`
--
-- Создание: Июн 04 2022 г., 11:52
-- Последнее обновление: Июн 05 2022 г., 11:39
--

DROP TABLE IF EXISTS `order_prod`;
CREATE TABLE `order_prod` (
  `id_order` int(9) NOT NULL,
  `id_catalog` int(11) NOT NULL,
  `count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `order_prod`
--

INSERT INTO `order_prod` (`id_order`, `id_catalog`, `count`) VALUES
(755110382, 2, 1),
(755110382, 3, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `posts`
--
-- Создание: Июн 03 2022 г., 17:10
-- Последнее обновление: Июн 05 2022 г., 11:08
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `Название` varchar(255) NOT NULL,
  `Дата` datetime NOT NULL,
  `Описание` text NOT NULL,
  `Изображение` text NOT NULL,
  `id_admin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `posts`
--

INSERT INTO `posts` (`id`, `Название`, `Дата`, `Описание`, `Изображение`, `id_admin`) VALUES
(4, 'Добавление в меню новой пиццы Виладжио', '2022-06-03 22:28:35', 'Картофель, бекон, шампиньоны, помидоры, моцарелла, соус Ранч, орегано.Стоить это чудо будет 345 руб.В меню появиться 01.01.2023.', 'images/posts/20220603222835862.jpg', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `view`
--
-- Создание: Июн 04 2022 г., 11:03
-- Последнее обновление: Июн 05 2022 г., 11:39
--

DROP TABLE IF EXISTS `view`;
CREATE TABLE `view` (
  `id` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `Вид` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `view`
--

INSERT INTO `view` (`id`, `count`, `Вид`) VALUES
(1, 591, 'pizza'),
(2, 608, 'pasta'),
(3, 126, 'salads'),
(4, 359, 'seafood'),
(5, 346, 'deserts');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ФИО` (`ФИО`),
  ADD KEY `Телефон` (`Телефон`);

--
-- Индексы таблицы `catalog`
--
ALTER TABLE `catalog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Вид` (`Вид`);

--
-- Индексы таблицы `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`,`Название`) USING BTREE,
  ADD KEY `id_client` (`id_client`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`Номер заказа`),
  ADD KEY `Телефон клиента` (`Телефон клиента`),
  ADD KEY `id_client` (`id_client`),
  ADD KEY `order_num` (`order_num`);

--
-- Индексы таблицы `order_prod`
--
ALTER TABLE `order_prod`
  ADD KEY `id_order` (`id_order`),
  ADD KEY `id_catalog` (`id_catalog`);

--
-- Индексы таблицы `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_admin` (`id_admin`);

--
-- Индексы таблицы `view`
--
ALTER TABLE `view`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT для таблицы `catalog`
--
ALTER TABLE `catalog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT для таблицы `message`
--
ALTER TABLE `message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `Номер заказа` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT для таблицы `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `view`
--
ALTER TABLE `view`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `catalog`
--
ALTER TABLE `catalog`
  ADD CONSTRAINT `catalog_ibfk_1` FOREIGN KEY (`Вид`) REFERENCES `view` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `message`
--
ALTER TABLE `message`
  ADD CONSTRAINT `message_ibfk_2` FOREIGN KEY (`id_client`) REFERENCES `accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`id_client`) REFERENCES `accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `order_prod`
--
ALTER TABLE `order_prod`
  ADD CONSTRAINT `order_prod_ibfk_1` FOREIGN KEY (`id_order`) REFERENCES `orders` (`order_num`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `order_prod_ibfk_2` FOREIGN KEY (`id_catalog`) REFERENCES `catalog` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`id_admin`) REFERENCES `accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
